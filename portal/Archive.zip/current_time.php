<?php include("wsp_rad/wsp_rad.inc.php");
echo get_current_time(); 
?>