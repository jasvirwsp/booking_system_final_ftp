                        <ul class="metismenu" id="side-menu">

                            
                            <li>
                            <a href="<?php echo $redirection_array[$user_role] ?: $redirection_array["all"]; ?>">
                                <i class="fe-arrow-right-circle"></i>
                                    <!-- <span class="badge badge-success float-right">00</span> -->
                                    <span> Dashboard </span>
                                </a>
                            </li>
                          

                            <li>
                                <a href="desk.php">
                                    <i class="fe-arrow-right-circle"></i>                                  
                                    <span>Desk</span>
                                </a>
                            </li>
                            <!-- <li>
                                <a href="booking.php">
                                    <i class="fe-arrow-right-circle"></i>                                  
                                    <span>Bookings</span>
                                </a>
                            </li> -->
                            <!-- <li>
                                <a href="notify.php">
                                    <i class="fe-arrow-right-circle"></i>                                  
                                    <span>Notify</span>
                                </a>
                            </li> -->

                            <li>
                                <a href="section.php">
                                    <i class="fe-arrow-right-circle"></i>                                  
                                    <span>Section</span>
                                </a>
                            </li>

                           <!-- <li>
                                <a href="javascript: void(0);">
                                <i class="fe-arrow-right-circle"></i>
                                    <span> Users </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    
                                     <li>
                                        <a href="add_user.php">Add User</a>
                                    </li>
                                                                        
                                    <li>
                                        <a href="manage_users.php">Manage Users</a>
                                    </li>
                                    <li>
                                        <a href="manage_staff.php">Manage Staff</a>
                                    </li>

                                </ul>
                            </li> -->

                            
                            <!-- <li>
                                <a href="#">
                                <i class="fe-arrow-right-circle"></i>
                                    <!-- <span class="badge badge-success float-right">00</span> -->
                                    <span class="backup_now">Backup DB</span>
                                </a>
                            </li> -->
                           
                           

                            
                        </ul>

                