<?php include("header.php"); ?>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

         <!-- ========== Left Sidebar Start ========== -->
           <?php //include("left_sidebar.php"); ?>
           <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page ml-0">
                <div class="content">

                  
                    <div class="container-fluid">
                        <!-- Row Starts -->
 <div class="row">
<!-- Col 1 -->
        <div class="col">
        
        
        </div>
<!-- Col 1 ends-->
</div>
<!-- Row Ends -->       
                        
                    </div> <!-- container -->

                </div> <!-- content -->

                            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
        <?php include("core_scripts.php");?>
<script>
// $(document).ready(function() {
//  window.print();
//  setTimeout(function () { window.close(); }, 100);
	  
// }); 

</script>