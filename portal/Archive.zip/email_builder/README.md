# jQuery Drag and Drop Mail Builder
This is plug and play drag and drop jQuery builder for mail templates. This editor is designed to fit all Amazon rules and can generate dynamic clean HTML template fast and multidevice secure.

You need just to download, configure URL path on line `156` and you are ready for rock.

DEMO: http://creativform.com/mail-editor/

LINE 156 configuration
```
// ...
    }('/mail-editor')); // example: http://localhost/mail-editor
	
// or...


// ...
    }('/')); // example: http://localhost/
```

@autor: Ivijan-Stefan Stipic <creativform@gmail.com>