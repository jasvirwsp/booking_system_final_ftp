<!DOCTYPE html>
<!-- saved from url=(0088)https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-rad-snippets/ -->
<html lang="en-US"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ready to go RAD Snippets | WSP RAD Documentation</title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://jasminderpalsingh.info/wsprad/xmlrpc.php">

<title>Ready to go RAD Snippets – WSP RAD Documentation</title>
<meta name="robots" content="noindex,follow">
<link rel="dns-prefetch" href="https://fonts.googleapis.com/">
<link rel="dns-prefetch" href="https://s.w.org/">
<link rel="alternate" type="application/rss+xml" title="WSP RAD Documentation » Feed" href="https://jasminderpalsingh.info/wsprad/feed/">
<link rel="alternate" type="application/rss+xml" title="WSP RAD Documentation » Comments Feed" href="https://jasminderpalsingh.info/wsprad/comments/feed/">
		<script async="" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/analytics.js.download"></script><script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/jasminderpalsingh.info\/wsprad\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.4"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/wp-emoji-release.min.js.download" type="text/javascript" defer=""></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="stylesheet" id="dashicons-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/dashicons.min.css" type="text/css" media="all">
<link rel="stylesheet" id="admin-bar-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/admin-bar.min.css" type="text/css" media="all">
<link rel="stylesheet" id="wp-block-library-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/style.min.css" type="text/css" media="all">
<link rel="stylesheet" id="ivory-search-styles-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/ivory-search.css" type="text/css" media="all">
<link rel="stylesheet" id="wedocs-styles-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="bus_leader-style-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/style.css" type="text/css" media="all">
<link rel="stylesheet" id="bus_leader-google-fonts2-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/css" type="text/css" media="all">
<link rel="stylesheet" id="bus_leader-font-awesome-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/font-awesome.min.css" type="text/css" media="all">
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/jquery.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/jquery-migrate.min.js.download"></script>
<link rel="https://api.w.org/" href="https://jasminderpalsingh.info/wsprad/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://jasminderpalsingh.info/wsprad/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://jasminderpalsingh.info/wsprad/wp-includes/wlwmanifest.xml"> 
<link rel="prev" title="Turn ON phone without power button" href="https://jasminderpalsingh.info/wsprad/docs/wordpress/tricks-and-hacks/turn-on-phone-without-power-button/">
<link rel="next" title="Ready to Go Javasrcipt/Jquery Snippets" href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-javasrcipt-jquery-snippets/">
<meta name="generator" content="WordPress 5.2.4">
<link rel="canonical" href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-rad-snippets/">
<link rel="shortlink" href="https://jasminderpalsingh.info/wsprad/?p=1161">
<link rel="alternate" type="application/json+oembed" href="https://jasminderpalsingh.info/wsprad/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjasminderpalsingh.info%2Fwsprad%2Fdocs%2Fwsp-rad%2Fquick-codes%2Fready-to-go-rad-snippets%2F">
<link rel="alternate" type="text/xml+oembed" href="https://jasminderpalsingh.info/wsprad/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjasminderpalsingh.info%2Fwsprad%2Fdocs%2Fwsp-rad%2Fquick-codes%2Fready-to-go-rad-snippets%2F&amp;format=xml">
<style type="text/css" media="print">#wpadminbar { display:none; }</style>
	<style type="text/css" media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>
	
<!-- BEGIN ExactMetrics v5.3.8 Universal Analytics - https://exactmetrics.com/ -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-140155580-2', 'auto');
  ga('send', 'pageview');
</script>
<!-- END ExactMetrics Universal Analytics -->
		<style type="text/css" id="wp-custom-css">
			.header-container{display:none;}
.wedocs-single-wrap{padding:0 5%;}		</style>
		</head>

<body class="docs-template-default single single-docs postid-1161 logged-in admin-bar  customize-support" cz-shortcut-listen="true">
<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-rad-snippets/#content">Skip to content</a>

	<header id="masthead" class="site-header" role="banner">
		<div class="site-branding">
						<h1 class="site-title"><a href="https://jasminderpalsingh.info/wsprad/" rel="home" style="color:#ffffff">WSP RAD Documentation</a></h1>
			<h2 class="site-description">Personal Notebook</h2>
		</div><!-- .site-branding -->

		<div id="nav-menu-toggle" class="menu-toggle">
		    <i class="fa fa-bars"></i>
		    <a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-rad-snippets/#site-navigation" class="screen-reader-text">Menu</a>
		</div><!-- #nav-menu-toggle -->

		<nav id="site-navigation" class="main-navigation" role="navigation">
			<div class="menu-menu-1-container"><ul id="menu-menu-1" class="menu nav-menu sf-js-enabled sf-arrows" style="touch-action: pan-y;"><li id="menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-40"><a href="https://jasminderpalsingh.info/wsprad/">Home</a></li>
<li id="menu-item-43" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-43"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/start-here/include-wsp-rad/">Docs</a></li>
</ul></div>		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

	
	<div class="header-container">

					<div class="header-image" style="background-image: url(&#39;https://jasminderpalsingh.info/wsprad/wp-content/themes/business-leader/images/default-featured-image.jpg&#39;)"></div><!-- .header-image -->
		
		
	</div><!-- .header-image-container -->
	
	<div id="content" class="site-content">
    <div id="primary" class="content-area"><main id="main" class="site-main" role="main">
    
        <div class="wedocs-single-wrap">

            
                <div class="wedocs-sidebar wedocs-hide-mobile">
    
    <h3 class="widget-title">WSP RAD</h3>

            <ul class="doc-nav-list">
            <li class="page_item page-item-1433"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/delete-multiple-records-rad-v10-simulor/">Delete Multiple records rad v10+ simulor</a></li>
<li class="page_item page-item-1428"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/fetch-api-search-parameters/">Fetch API Search Parameters</a></li>
<li class="page_item page-item-1082"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/json-api-2/">JSON API</a></li>
<li class="page_item page-item-1343"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/migrating-from-v8-to-v10/">Migrating from v8+ to v10</a></li>
<li class="page_item page-item-1389"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/rad-v11-bug-fixes-feature-additions-list/">RAD v11 | Bug Fixes | Feature Additions List</a></li>
<li class="page_item page-item-11 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/start-here/">Start Here</a>
<ul class="children">
	<li class="page_item page-item-21"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/start-here/include-wsp-rad/">Include WSP RAD</a></li>
	<li class="page_item page-item-46"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/start-here/steps/">Steps</a></li>
</ul>
</li>
<li class="page_item page-item-29 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/input-validations/">Input Validations</a>
<ul class="children">
	<li class="page_item page-item-30"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/input-validations/validations-check/">Validations Check</a></li>
</ul>
</li>
<li class="page_item page-item-34 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/">Javascript</a>
<ul class="children">
	<li class="page_item page-item-35"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/insert-entry-js/">Insert Entry JS</a></li>
	<li class="page_item page-item-38"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/update-entry-js/">Update Entry JS</a></li>
	<li class="page_item page-item-39"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/delete-entry-js/">Delete Entry JS</a></li>
	<li class="page_item page-item-118"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/insert-entry-v2/">Insert Entry (V2)</a></li>
	<li class="page_item page-item-301"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/insert-entry-v2-multi-form/">Insert Entry V2 Multi form</a></li>
	<li class="page_item page-item-141"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/update-entry-v2/">Update Entry (V2)</a></li>
	<li class="page_item page-item-306"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/update-entry-v2-multi-form/">Update Entry V2 Multi form</a></li>
	<li class="page_item page-item-144"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/delete-entry-v2/">Delete Entry (V2)</a></li>
	<li class="page_item page-item-393"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/javascript/delete-multiple-records/">Delete Multiple Records</a></li>
</ul>
</li>
<li class="page_item page-item-51 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/controllers/">Controllers</a>
<ul class="children">
	<li class="page_item page-item-52"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/controllers/initiate/">Initiate</a></li>
	<li class="page_item page-item-54"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/controllers/records-controller/">Records Controller</a></li>
	<li class="page_item page-item-55"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/controllers/meta-controller/">Meta Controller</a></li>
	<li class="page_item page-item-56"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/controllers/user-controller/">User Controller</a></li>
	<li class="page_item page-item-57"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/controllers/array-resolver/">Array Resolver</a></li>
	<li class="page_item page-item-58"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/controllers/validations-controller/">Validations Controller</a></li>
</ul>
</li>
<li class="page_item page-item-61 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/examples/">Examples</a>
<ul class="children">
	<li class="page_item page-item-62"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/examples/edit-update-record/">Edit/Update Record</a></li>
	<li class="page_item page-item-73"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/examples/fetch-all-records-with-meta/">Fetch all records with Meta</a></li>
	<li class="page_item page-item-83"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/examples/search-with-record-id-or-from-any-meta-content/">Search with Record ID or from any Meta content</a></li>
	<li class="page_item page-item-93"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/examples/get-select-options-based-on-record-type/">Get Select options based on record type</a></li>
	<li class="page_item page-item-98"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/examples/fetch-records-including-meta-based-on-meta-values/">Fetch records including meta based on meta values</a></li>
</ul>
</li>
<li class="page_item page-item-87 page_item_has_children current_page_ancestor current_page_parent"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/">Quick Codes</a>
<ul class="children">
	<li class="page_item page-item-1262"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/1262-2/">#1262 (no title)</a></li>
	<li class="page_item page-item-1216"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/apply-datatables-with-mobile-responsiveness/">Apply datatables with mobile responsiveness</a></li>
	<li class="page_item page-item-1283"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/auto-suggest-rad-v10/">Auto suggest rad v10</a></li>
	<li class="page_item page-item-1252"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/automated-emails-mailchimp-based-on-day-date/">Automated Emails Mailchimp based on day/date</a></li>
	<li class="page_item page-item-88 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/basic/">Basic</a>
	<ul class="children">
		<li class="page_item page-item-1012"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/basic/auto-generate-variables/">Auto Generate Variables</a></li>
	</ul>
</li>
	<li class="page_item page-item-1272"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/calender-with-php/">Calender with PHP</a></li>
	<li class="page_item page-item-1341"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/change-search-placeholder-text/">Change search placeholder text</a></li>
	<li class="page_item page-item-1244"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/class-numberformatter-not-found/">Class ‘NumberFormatter’ not found</a></li>
	<li class="page_item page-item-1180"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/convert-to-string/">Convert to string</a></li>
	<li class="page_item page-item-1220"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/copy-project-android/">Copy project Android</a></li>
	<li class="page_item page-item-970"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/edit-record-automatically/">Edit Record automatically | Prefill input values POST</a></li>
	<li class="page_item page-item-1297"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/facebook-pixel-woocomerce/">Facebook pixel woocomerce</a></li>
	<li class="page_item page-item-1028"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/fetch-records-with-multiple-rows-combination/">Fetch records with multiple rows combination</a></li>
	<li class="page_item page-item-1328"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/file-id-to-url-and-button/">File ID to url and button</a></li>
	<li class="page_item page-item-1264"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/fix-print-table-issue-on-next-page/">Fix print table issue on next page</a></li>
	<li class="page_item page-item-1125"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/force-download-image/">Force download image</a></li>
	<li class="page_item page-item-1131"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/force-https-with-htaccess/">Force https with htaccess</a></li>
	<li class="page_item page-item-1270"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/gallery-lightbox-images/">Gallery , lightbox images</a></li>
	<li class="page_item page-item-1102"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/get-image-url-from-image-record-id/">Get image url from image record id</a></li>
	<li class="page_item page-item-1255"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/html-table-to-csv-excel/">Html table to csv / excel</a></li>
	<li class="page_item page-item-1211"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/one-click-update-meta/">One Click Quick Update Meta</a></li>
	<li class="page_item page-item-1097"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/page-refresh/">Page REfresh</a></li>
	<li class="page_item page-item-1310"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/pass-paramter-to-url-jquery/">Pass paramter to url jquery</a></li>
	<li class="page_item page-item-1188"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/passthru-function/">Passthru function</a></li>
	<li class="page_item page-item-1123"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/prefill-input-values-with-get/">Prefill input values with GET</a></li>
	<li class="page_item page-item-1085"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/prefill-inputs-with-url-values/">Prefill Inputs with URL values</a></li>
	<li class="page_item page-item-1202"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/quick-for-loop/">Quick for loop</a></li>
	<li class="page_item page-item-1163"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-javasrcipt-jquery-snippets/">Ready to Go Javasrcipt/Jquery Snippets</a></li>
	<li class="page_item page-item-1161 current_page_item"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-rad-snippets/" aria-current="page">Ready to go RAD Snippets</a></li>
	<li class="page_item page-item-1127"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/regex-to-find-matching-data/">Regex to find matching data in visual code</a></li>
	<li class="page_item page-item-1182"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/remove-first-key-from-foreach-loop/">Remove first key from foreach loop</a></li>
	<li class="page_item page-item-1334"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/send-unicode-smsm/">Send unicode smsm</a></li>
	<li class="page_item page-item-1153"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/show-file-upload-error-formstone/">Show File Upload Error Formstone</a></li>
	<li class="page_item page-item-1108"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/single-input-dynamic-dom-elements-creation/">Single Input Dynamic DOM Elements Creation</a></li>
	<li class="page_item page-item-1306"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/sort-posts-by-ascending-or-descending/">Sort posts by Ascending or descending</a></li>
	<li class="page_item page-item-1326"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/test-fluent-pdo-query-in-phpmyadmin-sql/">Test fluent pdo query in phpmyadmin sql</a></li>
	<li class="page_item page-item-1322"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/under-maintenance-and-under-construction/">Under Maintenance and Under Construction</a></li>
	<li class="page_item page-item-1277"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/view-page-rad-v10/">View page RAD v10+</a></li>
	<li class="page_item page-item-1370"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/years-between-two-dates/">Years between two dates</a></li>
	<li class="page_item page-item-147"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/crud-edit-view-delete-button/">CRUD ( Edit/View Delete Button)</a></li>
	<li class="page_item page-item-196"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/row-highlighter/">Row Highlighter</a></li>
	<li class="page_item page-item-197"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/table-sort-on-click-td/">Table sort on click (TD)</a></li>
	<li class="page_item page-item-415"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/get-record-meta-with-record-id-function/">Get Record Meta with Record Id function</a></li>
</ul>
</li>
<li class="page_item page-item-104 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/print-tables-pages/">Print Tables / Pages</a>
<ul class="children">
	<li class="page_item page-item-105"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/print-tables-pages/print-snippet/">Print snippet</a></li>
</ul>
</li>
<li class="page_item page-item-129 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/kb/">KB</a>
<ul class="children">
	<li class="page_item page-item-130"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/kb/arrays/">Arrays</a></li>
</ul>
</li>
<li class="page_item page-item-133 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/login/">Login and Users</a>
<ul class="children">
	<li class="page_item page-item-1057"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/login/check-if-already-logged-in/">Check if already logged in</a></li>
	<li class="page_item page-item-134"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/login/login-page-and-sessions/">Login Page and sessions (Single User)</a></li>
	<li class="page_item page-item-693"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/login/quick-if-else-of-rol/">Quick if else of role</a></li>
	<li class="page_item page-item-138"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/login/login-page-and-sessions-multi-users/">Login page and sessions (Multi Users)</a></li>
	<li class="page_item page-item-775"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/login/add-user/">Add User / Signup</a></li>
	<li class="page_item page-item-778"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/login/list-users/">List Users</a></li>
	<li class="page_item page-item-779"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/login/get-logged-user-details-with-meta/">Get logged user details with meta</a></li>
</ul>
</li>
<li class="page_item page-item-161 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/hooks/">Hooks</a>
<ul class="children">
	<li class="page_item page-item-162"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/hooks/insert-hook-file/">Insert Hook File</a></li>
</ul>
</li>
<li class="page_item page-item-218 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/sorted-fetching/">Sorted Fetching</a>
<ul class="children">
	<li class="page_item page-item-219"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/sorted-fetching/fetch-records-according-to-meta-value-asc-desc/">Fetch records according to Numeric meta value | ASC, DESC</a></li>
	<li class="page_item page-item-275"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/sorted-fetching/fetch-records-and-meta-alphabetically/">Fetch records with meta alphabetically</a></li>
</ul>
</li>
<li class="page_item page-item-287 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/json-api/">JSON API</a>
<ul class="children">
	<li class="page_item page-item-288"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/json-api/fetch-all-with-meta_name/">Fetch all with meta_name</a></li>
	<li class="page_item page-item-289"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/json-api/fetch-all-with-record-id/">Fetch single with record id</a></li>
</ul>
</li>
<li class="page_item page-item-309 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/bootstrap-base-template/">Bootstrap Base Template</a>
<ul class="children">
	<li class="page_item page-item-310"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/bootstrap-base-template/quick-bootstrap-page-layout/">Quick Bootstrap Page Layout</a></li>
</ul>
</li>
<li class="page_item page-item-418"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/print-table-with-jquery/">Export table to CSV</a></li>
<li class="page_item page-item-424"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/export-xls/">Export table to XLS</a></li>
<li class="page_item page-item-508"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/errors-and-logging/">Errors and logging</a></li>
<li class="page_item page-item-542 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/jquery-data-table/">Jquery Data Table</a>
<ul class="children">
	<li class="page_item page-item-543"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/jquery-data-table/sort-by-column/">Sort by column</a></li>
</ul>
</li>
<li class="page_item page-item-560 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/file-upload/">File Upload</a>
<ul class="children">
	<li class="page_item page-item-561"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/file-upload/file-upload-on-edit-page-or-with-already-existing-id/">File Upload on edit page or with already existing id | Multi file</a></li>
	<li class="page_item page-item-836"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/file-upload/file-upload-on-edit-record-single-file/">File Upload On Edit record (Single File)</a></li>
	<li class="page_item page-item-584"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/file-upload/file-upload-on-new-record/">File Upload On New record (Single File)</a></li>
	<li class="page_item page-item-754"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/file-upload/multi-file-upload-on-new-record/">Multi File Upload on New Record</a></li>
</ul>
</li>
<li class="page_item page-item-633 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/pdfmake/">PDFmake</a>
<ul class="children">
	<li class="page_item page-item-634"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/pdfmake/convert-html-table-to-pdfmake/">Convert html table to pdfmake</a></li>
	<li class="page_item page-item-834"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/pdfmake/d-tofixed-is-not-a-function-when-using-custom-width-height-for-pagesize/">d.toFixed is not a function when using custom width height for pageSize</a></li>
	<li class="page_item page-item-783"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/pdfmake/invoice-markup/">Invoice Markup</a></li>
	<li class="page_item page-item-1001"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/pdfmake/tables/">Tables</a></li>
	<li class="page_item page-item-832"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/pdfmake/thermal-print/">Thermal print</a></li>
	<li class="page_item page-item-718"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/pdfmake/installation/">Installation</a></li>
	<li class="page_item page-item-815"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/pdfmake/problem-with-colspan-on-next-page/">Problem with colspan on next page</a></li>
</ul>
</li>
<li class="page_item page-item-656 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/listing-styles/">Listing Styles</a>
<ul class="children">
	<li class="page_item page-item-657"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/listing-styles/fully-featured-table/">Fully featured Table</a></li>
</ul>
</li>
<li class="page_item page-item-771 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/upgrading-from-all-versions-to-v4/">Upgrading from all versions to v4</a>
<ul class="children">
	<li class="page_item page-item-772"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/upgrading-from-all-versions-to-v4/how-to/">How to</a></li>
</ul>
</li>
<li class="page_item page-item-923 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/auto-suggestions/">Auto Suggestions</a>
<ul class="children">
	<li class="page_item page-item-924"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/auto-suggestions/auto-suggestion-without-record-id/">Auto suggestion without record id</a></li>
</ul>
</li>
<li class="page_item page-item-802 page_item_has_children"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/backups/">Backups</a>
<ul class="children">
	<li class="page_item page-item-803"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/backups/manual-backup/">Manual and Auto Backup</a></li>
</ul>
</li>
        </ul>
    </div>
            
            <div class="wedocs-single-content">
                <ol class="wedocs-breadcrumb" itemscope="" itemtype="http://schema.org/BreadcrumbList"><li><i class="wedocs-icon wedocs-icon-home"></i></li><li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="https://jasminderpalsingh.info/wsprad/">
        <span itemprop="name">Home</span></a>
        <meta itemprop="position" content="1">
    </li><li class="delimiter"><i class="wedocs-icon wedocs-icon-angle-right"></i></li><li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="https://jasminderpalsingh.info/wsprad/docs/">
        <span itemprop="name">Docs</span></a>
        <meta itemprop="position" content="2">
    </li><li class="delimiter"><i class="wedocs-icon wedocs-icon-angle-right"></i></li><li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/">
        <span itemprop="name">WSP RAD</span></a>
        <meta itemprop="position" content="4">
    </li> <li class="delimiter"><i class="wedocs-icon wedocs-icon-angle-right"></i></li> <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/">
        <span itemprop="name">Quick Codes</span></a>
        <meta itemprop="position" content="3">
    </li> <li class="delimiter"><i class="wedocs-icon wedocs-icon-angle-right"></i></li>  <li><span class="current">Ready to go RAD Snippets</span></li></ol>
                <article id="post-1161" class="post-1161 docs type-docs status-publish hentry" itemscope="" itemtype="http://schema.org/Article">
                    <header class="entry-header">
                        <h1 class="entry-title" itemprop="headline">Ready to go RAD Snippets</h1>
                                                    <a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-rad-snippets/#" class="wedocs-print-article wedocs-hide-print wedocs-hide-mobile" title="Print this article"><i class="wedocs-icon wedocs-icon-print"></i></a>
                                            </header><!-- .entry-header -->

                    <div class="entry-content" itemprop="articleBody">
                        <p>Use this <a href="https://chrome.google.com/webstore/detail/findr/bidnaaogcagbdidehabnjfedabckhdgc">extension</a> for find replace :</p>
<p>Fetch Meta with Where. Replace <strong>rec_type</strong> with <strong>record_type</strong>.</p>
<div class="code-embed-wrapper"> <div class="code-embed-infos"> </div> <pre class=" code-embed-pre language-php" data-start="1" data-line-offset="0"><code class=" code-embed-code language-php"><span class="token comment" spellcheck="true">//Where array</span>
                            <span class="token variable">$where_array_rec_type</span> <span class="token operator">=</span> <span class="token keyword">array</span><span class="token punctuation">(</span><span class="token string">"meta_name"</span><span class="token operator">=</span><span class="token operator">&gt;</span><span class="token string">""</span><span class="token punctuation">,</span><span class="token string">"meta_value"</span><span class="token operator">=</span><span class="token operator">&gt;</span><span class="token string">""</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
                            <span class="token variable">$results_rec_type</span> <span class="token operator">=</span> <span class="token variable">$meta_fetch_controller</span><span class="token operator">-</span><span class="token operator">&gt;</span><span class="token function">fetch_meta_with_where</span><span class="token punctuation">(</span><span class="token string">"rec_type"</span><span class="token punctuation">,</span><span class="token variable">$where_array_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">;</span>

                            <span class="token comment" spellcheck="true">//Lets loop through washing machine</span>
                            <span class="token keyword">foreach</span><span class="token punctuation">(</span><span class="token variable">$results_rec_type</span> <span class="token keyword">as</span> <span class="token variable">$single_result_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">{</span>
                                <span class="token variable">$rec_id_rec_type</span> <span class="token operator">=</span> <span class="token variable">$single_result_rec_type</span><span class="token punctuation">[</span><span class="token string">"record_id"</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
                                <span class="token variable">$rec_meta_rec_type</span> <span class="token operator">=</span> <span class="token function">get_rec_meta_by_rec_id</span><span class="token punctuation">(</span><span class="token string">"rec_type"</span><span class="token punctuation">,</span><span class="token variable">$rec_id_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 <span class="token delimiter">?&gt;</span>

                               <span class="token delimiter">&lt;?php</span>

                            <span class="token punctuation">}</span> </code></pre> </div>
<p>&nbsp;</p>
<p>Only where array with fetch controller</p>
<div class="code-embed-wrapper"> <div class="code-embed-infos"> </div> <pre class=" code-embed-pre language-markup" data-start="1" data-line-offset="0"><code class=" code-embed-code language-markup">//Where array
                            $where_array_rec_type = array("meta_name"=&gt;"","meta_value"=&gt;"");
                            $results_rec_type = $meta_fetch_controller-&gt;fetch_meta_with_where("rec_type",$where_array_rec_type);</code></pre> </div>
<p>Where array RAD v10 +</p>
<div class="code-embed-wrapper"> <div class="code-embed-infos"> </div> <pre class=" code-embed-pre language-php" data-start="1" data-line-offset="0"><code class=" code-embed-code language-php"><span class="token comment" spellcheck="true">//Where array</span>
    <span class="token variable">$where_array_rec_type</span> <span class="token operator">=</span> <span class="token keyword">array</span><span class="token punctuation">(</span><span class="token string">""</span><span class="token operator">=</span><span class="token operator">&gt;</span><span class="token string">""</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token variable">$results_rec_type</span> <span class="token operator">=</span> <span class="token variable">$records_fetch_controller</span><span class="token operator">-</span><span class="token operator">&gt;</span><span class="token function">fetch_record_with_where</span><span class="token punctuation">(</span><span class="token string">"rec_type"</span><span class="token punctuation">,</span><span class="token variable">$where_array_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token variable">$count_results_rec_type</span> <span class="token operator">=</span> <span class="token function">count</span><span class="token punctuation">(</span><span class="token variable">$results_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">;</span></code></pre> </div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>Get Meta value .</p>
<div class="code-embed-wrapper"> <div class="code-embed-infos"> </div> <pre class=" code-embed-pre language-markup" data-start="1" data-line-offset="0"><code class=" code-embed-code language-markup"><span class="token prolog">&lt;?php echo title_case(get_meta_value($rec_meta_rec_type,"")); ?&gt;</span></code></pre> </div>
<p>&nbsp;</p>
<p>Where array RAD v11 +</p>
<div class="code-embed-wrapper"> <div class="code-embed-infos"> </div> <pre class=" code-embed-pre language-php" data-start="1" data-line-offset="0"><code class=" code-embed-code language-php"><span class="token comment" spellcheck="true">//Where array</span>
    <span class="token variable">$where_array_rec_type</span> <span class="token operator">=</span> <span class="token keyword">array</span><span class="token punctuation">(</span><span class="token string">""</span><span class="token operator">=</span><span class="token operator">&gt;</span><span class="token string">""</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token variable">$results_rec_type</span> <span class="token operator">=</span> <span class="token variable">$records_fetch_controller</span><span class="token operator">-</span><span class="token operator">&gt;</span><span class="token function">fetch_record_with_where</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">"rec_type"</span><span class="token punctuation">,</span><span class="token variable">$where_array_rec_type</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token variable">$count_results_rec_type</span> <span class="token operator">=</span> <span class="token function">count</span><span class="token punctuation">(</span><span class="token variable">$results_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">;</span></code></pre> </div>
<p>With Loop</p>
<div class="code-embed-wrapper"> <div class="code-embed-infos"> </div> <pre class=" code-embed-pre language-php" data-start="1" data-line-offset="0"><code class=" code-embed-code language-php"><span class="token comment" spellcheck="true">//Where array</span>
    <span class="token variable">$where_array_rec_type</span> <span class="token operator">=</span> <span class="token keyword">array</span><span class="token punctuation">(</span><span class="token string">""</span><span class="token operator">=</span><span class="token operator">&gt;</span><span class="token string">""</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token variable">$results_rec_type</span> <span class="token operator">=</span> <span class="token variable">$records_fetch_controller</span><span class="token operator">-</span><span class="token operator">&gt;</span><span class="token function">fetch_record_with_where</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">"rec_type"</span><span class="token punctuation">,</span><span class="token variable">$where_array_rec_type</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token variable">$count_results_rec_type</span> <span class="token operator">=</span> <span class="token function">count</span><span class="token punctuation">(</span><span class="token variable">$results_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">;</span>

<span class="token comment" spellcheck="true">//Lets loop through washing machine</span>
                            <span class="token keyword">foreach</span><span class="token punctuation">(</span><span class="token variable">$results_rec_type</span> <span class="token keyword">as</span> <span class="token variable">$single_result_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">{</span>
                                <span class="token variable">$rec_id_rec_type</span> <span class="token operator">=</span> <span class="token variable">$single_result_rec_type</span><span class="token punctuation">[</span><span class="token string">"record_id"</span><span class="token punctuation">]</span><span class="token punctuation">;</span>
                                <span class="token variable">$rec_meta_rec_type</span> <span class="token operator">=</span> <span class="token function">get_rec_meta_by_rec_id</span><span class="token punctuation">(</span><span class="token string">"rec_type"</span><span class="token punctuation">,</span><span class="token variable">$rec_id_rec_type</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
 <span class="token delimiter">?&gt;</span>

                               <span class="token delimiter">&lt;?php</span>

                            <span class="token punctuation">}</span> </code></pre> </div>
<p>&nbsp;</p>
<p>Fetch just count by record_type and where_array (v11)</p>
<div class="code-embed-wrapper"> <div class="code-embed-infos"> </div> <pre class=" code-embed-pre language-php" data-start="1" data-line-offset="0"><code class=" code-embed-code language-php"><span class="token comment" spellcheck="true">//Where array</span>
    <span class="token variable">$where_array_rec_type</span> <span class="token operator">=</span> <span class="token keyword">array</span><span class="token punctuation">(</span><span class="token string">""</span><span class="token operator">=</span><span class="token operator">&gt;</span><span class="token string">""</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
    <span class="token variable">$results_rec_type_count</span> <span class="token operator">=</span> <span class="token variable">$records_fetch_controller</span><span class="token operator">-</span><span class="token operator">&gt;</span><span class="token function">fetch_count_by_record_type_and_where_array</span><span class="token punctuation">(</span><span class="token punctuation">[</span><span class="token string">"rec_type"</span><span class="token punctuation">,</span><span class="token variable">$where_array_rec_type</span><span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span></code></pre> </div>
<p>&nbsp;</p>
<p>&nbsp;</p>
                    </div><!-- .entry-content -->

                    <footer class="entry-footer wedocs-entry-footer">
                        
                        <div class="wedocs-article-author" itemprop="author" itemscope="" itemtype="https://schema.org/Person">
                            <meta itemprop="name" content="admin">
                            <meta itemprop="url" content="https://jasminderpalsingh.info/wsprad/author/admin/">
                        </div>

                        <meta itemprop="datePublished" content="2019-06-12T03:25:37+00:00">
                        <time itemprop="dateModified" datetime="2019-10-28T02:45:14+00:00">Updated on October 28, 2019</time>
                    </footer>

                    <nav class="wedocs-doc-nav wedocs-hide-print"><h3 class="assistive-text screen-reader-text">Doc navigation</h3><span class="nav-next"><a href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/crud-edit-view-delete-button/">CRUD ( Edit/View Delete Button) →</a></span></nav>
                    
                    
                </article><!-- #post-## -->
            </div><!-- .wedocs-single-content -->
        </div><!-- .wedocs-single-wrap -->

    
    </main><!-- .site-main --></div><!-- .content-area -->

	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
				<div class="site-info">
			© 2019 <a href="https://jasminderpalsingh.info/wsprad" rel="site url">WSP RAD Documentation</a>		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<!--
The IP2Location Redirection is using IP2Location LITE geolocation database. Please visit http://lite.ip2location.com for more information.
-->
<link rel="stylesheet" id="prismcss-css" href="./Ready to go RAD Snippets _ WSP RAD Documentation_files/prism.css" type="text/css" media="all">
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/admin-bar.min.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/ivory-search.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/anchor.min.js.download"></script>
<script type="text/javascript">
/* <![CDATA[ */
var weDocs_Vars = {"ajaxurl":"https:\/\/jasminderpalsingh.info\/wsprad\/wp-admin\/admin-ajax.php","nonce":"4ed1034ea8","style":"https:\/\/jasminderpalsingh.info\/wsprad\/wp-content\/plugins\/wedocs\/assets\/css\/print.css","powered":"\u00a9 WSP RAD Documentation, 2019. Powered by weDocs<br>https:\/\/jasminderpalsingh.info\/wsprad"};
/* ]]> */
</script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/frontend.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/enquire.min.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/superfish.min.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/imagesloaded.min.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/masonry.min.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/bus-leader-scripts.min.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/bj-lazy-load.min.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/wp-embed.min.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/prism.js.download"></script>
<script type="text/javascript" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/prism-normalize-whitespace.min.js.download"></script>
	<!--[if lte IE 8]>
		<script type="text/javascript">
			document.body.className = document.body.className.replace( /(^|\s)(no-)?customize-support(?=\s|$)/, '' ) + ' no-customize-support';
		</script>
	<![endif]-->
	<!--[if gte IE 9]><!-->
		<script type="text/javascript">
			(function() {
				var request, b = document.body, c = 'className', cs = 'customize-support', rcs = new RegExp('(^|\\s+)(no-)?'+cs+'(\\s+|$)');

						request = true;
		
				b[c] = b[c].replace( rcs, ' ' );
				// The customizer requires postMessage and CORS (if the site is cross domain)
				b[c] += ( window.postMessage && request ? ' ' : ' no-' ) + cs;
			}());
		</script>
	<!--<![endif]-->
			<div id="wpadminbar" class="">
							<a class="screen-reader-shortcut" href="https://jasminderpalsingh.info/wsprad/docs/wsp-rad/quick-codes/ready-to-go-rad-snippets/#wp-toolbar" tabindex="1">Skip to toolbar</a>
						<div class="quicklinks" id="wp-toolbar" role="navigation" aria-label="Toolbar">
				<ul id="wp-admin-bar-root-default" class="ab-top-menu"><li id="wp-admin-bar-wp-logo" class="menupop"><a class="ab-item" aria-haspopup="true" href="https://jasminderpalsingh.info/wsprad/wp-admin/about.php"><span class="ab-icon"></span><span class="screen-reader-text">About WordPress</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-wp-logo-default" class="ab-submenu"><li id="wp-admin-bar-about"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/about.php">About WordPress</a></li></ul><ul id="wp-admin-bar-wp-logo-external" class="ab-sub-secondary ab-submenu"><li id="wp-admin-bar-wporg"><a class="ab-item" href="https://wordpress.org/">WordPress.org</a></li><li id="wp-admin-bar-documentation"><a class="ab-item" href="https://codex.wordpress.org/">Documentation</a></li><li id="wp-admin-bar-support-forums"><a class="ab-item" href="https://wordpress.org/support/">Support</a></li><li id="wp-admin-bar-feedback"><a class="ab-item" href="https://wordpress.org/support/forum/requests-and-feedback">Feedback</a></li></ul></div></li><li id="wp-admin-bar-site-name" class="menupop"><a class="ab-item" aria-haspopup="true" href="https://jasminderpalsingh.info/wsprad/wp-admin/">WSP RAD Documentation</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-site-name-default" class="ab-submenu"><li id="wp-admin-bar-dashboard"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/">Dashboard</a></li></ul><ul id="wp-admin-bar-appearance" class="ab-submenu"><li id="wp-admin-bar-themes"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/themes.php">Themes</a></li><li id="wp-admin-bar-widgets"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/widgets.php">Widgets</a></li><li id="wp-admin-bar-menus"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/nav-menus.php">Menus</a></li><li id="wp-admin-bar-header" class="hide-if-customize"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/themes.php?page=custom-header">Header</a></li></ul></div></li><li id="wp-admin-bar-customize" class="hide-if-no-customize"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/customize.php?url=https%3A%2F%2Fjasminderpalsingh.info%2Fwsprad%2Fdocs%2Fwsp-rad%2Fquick-codes%2Fready-to-go-rad-snippets%2F">Customize</a></li><li id="wp-admin-bar-updates"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/update-core.php" title="16 Plugin Updates, 6 Theme Updates"><span class="ab-icon"></span><span class="ab-label">22</span><span class="screen-reader-text">16 Plugin Updates, 6 Theme Updates</span></a></li><li id="wp-admin-bar-comments"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/edit-comments.php"><span class="ab-icon"></span><span class="ab-label awaiting-mod pending-count count-0" aria-hidden="true">0</span><span class="screen-reader-text comments-in-moderation-text">0 Comments in moderation</span></a></li><li id="wp-admin-bar-new-content" class="menupop"><a class="ab-item" aria-haspopup="true" href="https://jasminderpalsingh.info/wsprad/wp-admin/post-new.php"><span class="ab-icon"></span><span class="ab-label">New</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-new-content-default" class="ab-submenu"><li id="wp-admin-bar-new-post"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/post-new.php">Post</a></li><li id="wp-admin-bar-new-media"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/media-new.php">Media</a></li><li id="wp-admin-bar-new-page"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/post-new.php?post_type=page">Page</a></li><li id="wp-admin-bar-new-docs"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/post-new.php?post_type=docs">Doc</a></li><li id="wp-admin-bar-new-user"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/user-new.php">User</a></li></ul></div></li><li id="wp-admin-bar-edit"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/post.php?post=1161&amp;action=edit">Edit Documentation</a></li></ul><ul id="wp-admin-bar-top-secondary" class="ab-top-secondary ab-top-menu"><li id="wp-admin-bar-search" class="admin-bar-search"><div class="ab-item ab-empty-item" tabindex="-1"><form action="https://jasminderpalsingh.info/wsprad/" method="get" id="adminbarsearch"><input class="adminbar-input" name="s" id="adminbar-search" type="text" value="" maxlength="150"><label for="adminbar-search" class="screen-reader-text">Search</label><input type="submit" class="adminbar-button" value="Search"></form></div></li><li id="wp-admin-bar-my-account" class="menupop with-avatar"><a class="ab-item" aria-haspopup="true" href="https://jasminderpalsingh.info/wsprad/wp-admin/profile.php">Howdy, <span class="display-name">admin</span><img alt="" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/4c2482f91ed524419fc52eb32caf11f0.jpeg" data-lazy-type="image" data-lazy-src="https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=26&amp;d=mm&amp;r=g" data-lazy-srcset="https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=52&amp;d=mm&amp;r=g 2x" class="lazy avatar avatar-26 photo lazy-loaded" height="26" width="26" srcset="https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=52&amp;d=mm&amp;r=g 2x"><noscript><img alt='' src='https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=26&#038;d=mm&#038;r=g' srcset='https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=52&#038;d=mm&#038;r=g 2x' class='avatar avatar-26 photo' height='26' width='26' /></noscript></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-user-actions" class="ab-submenu"><li id="wp-admin-bar-user-info"><a class="ab-item" tabindex="-1" href="https://jasminderpalsingh.info/wsprad/wp-admin/profile.php"><img alt="" src="./Ready to go RAD Snippets _ WSP RAD Documentation_files/4c2482f91ed524419fc52eb32caf11f0(1).jpeg" data-lazy-type="image" data-lazy-src="https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=64&amp;d=mm&amp;r=g" data-lazy-srcset="https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=128&amp;d=mm&amp;r=g 2x" class="lazy avatar avatar-64 photo lazy-loaded" height="64" width="64" srcset="https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=128&amp;d=mm&amp;r=g 2x"><noscript><img alt='' src='https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=64&#038;d=mm&#038;r=g' srcset='https://secure.gravatar.com/avatar/4c2482f91ed524419fc52eb32caf11f0?s=128&#038;d=mm&#038;r=g 2x' class='avatar avatar-64 photo' height='64' width='64' /></noscript><span class="display-name">admin</span></a></li><li id="wp-admin-bar-edit-profile"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-admin/profile.php">Edit My Profile</a></li><li id="wp-admin-bar-logout"><a class="ab-item" href="https://jasminderpalsingh.info/wsprad/wp-login.php?action=logout&amp;_wpnonce=54107ba993">Log Out</a></li></ul></div></li></ul>			</div>
						<a class="screen-reader-shortcut" href="https://jasminderpalsingh.info/wsprad/wp-login.php?action=logout&amp;_wpnonce=54107ba993">Log Out</a>
					</div>

		


</body></html>