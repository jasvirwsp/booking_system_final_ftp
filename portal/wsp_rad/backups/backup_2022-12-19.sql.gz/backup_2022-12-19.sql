-- Generation time: Mon, 19 Dec 2022 10:30:00 +0000
-- Host: localhost
-- DB name: wspclien_psnjas
/*!40030 SET NAMES UTF8 */;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `booking_visit_time` text NOT NULL,
  `booking_user_id` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `booking_insert_author` text NOT NULL,
  `booking_special_requirements` text NOT NULL,
  `booking_status` text NOT NULL,
  `booking_party_size` text NOT NULL,
  `booking_remarks` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4;

INSERT INTO `booking` VALUES ('123','02:00 pm','18','2022-12-01 14:52:05','2022-12-01 14:52:05','18','','Waiting','2',''),
('124','02:05 pm','18','2022-12-01 16:06:40','2022-12-01 16:07:08','18','','Cancelled','2',''),
('125','02:10 pm','18','2022-12-01 16:10:11','2022-12-01 16:14:34','18','test','Seated','2',''),
('126','02:15 pm','26','2022-12-01 16:14:32','2022-12-01 16:14:32','26','','Waiting','2',''),
('127','02:20 pm','18','2022-12-01 16:16:21','2022-12-01 16:16:21','18','','Waiting','2',''),
('129','02:00 pm','15','2022-12-18 15:00:53','2022-12-18 15:01:13','15','','Cancelled','2',''),
('131','02:05 pm','33','2022-12-18 20:00:38','2022-12-18 20:00:38','33','','Waiting','2',''),
('132','09:00 am','34','2022-12-19 9:38:25','2022-12-19 9:38:25','34','special','Waiting','2',''); 


DROP TABLE IF EXISTS `branding`;
CREATE TABLE `branding` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `branding_title` text NOT NULL,
  `branding_logo` text NOT NULL,
  `branding_color_scheme` text NOT NULL,
  `branding_footer` text NOT NULL,
  `branding_logo_width_lg` text NOT NULL,
  `branding_logo_width_sm` text NOT NULL,
  `branding_insert_author` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `branding` VALUES ('2','Paesano Orders Panel','4','dark','Paesano Orders Panel','50','50','15','2019-10-19 12:51:10','2022-12-01 11:05:32'); 


DROP TABLE IF EXISTS `desk`;
CREATE TABLE `desk` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `desk_size` text NOT NULL,
  `desk_time` text NOT NULL,
  `desk_count` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `desk_insert_author` text NOT NULL,
  `desk_start_time` text NOT NULL,
  `desk_status` text NOT NULL,
  `desk_closing_time` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `desk` VALUES ('4','2','5','10','2022-11-25 10:34:18','2022-12-19 9:33:25','15','09:00','on','23:00'),
('5','3','5','10','2022-11-25 10:34:26','2022-11-30 9:55:22','15','20:00','off','22:00'),
('6','4','5','10','2022-11-25 10:34:33','2022-11-30 9:55:47','15','20:00','off','22:00'),
('7','5-8','15','10','2022-11-25 10:34:41','2022-11-30 11:53:53','15','22:00','off','23:00'); 


DROP TABLE IF EXISTS `email`;
CREATE TABLE `email` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `email_from` text NOT NULL,
  `email_to` text NOT NULL,
  `email_subject` text NOT NULL,
  `email_status` text NOT NULL,
  `email_body` text NOT NULL,
  `email_attachments` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `email_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `email` VALUES ('1','wspkkptesting@gmail.com','jasminderwsp@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">402526</strong><br><br><br>Thanks','','2022-11-30 9:03:05','',''),
('2','wspkkptesting@gmail.com','jasminderwsp@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">081355</strong><br><br><br>Thanks','','2022-11-30 9:05:42','',''),
('3','wspkkptesting@gmail.com','jasminderwsp@gmail.com','Password Reset Successul','Sent','Hello , <br> Your request for forgot password is successful.<br><br><br>Thanks','','2022-11-30 9:10:52','',''),
('4','wspkkptesting@gmail.com','jasminderwsp@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">175990</strong><br><br><br>Thanks','','2022-11-30 9:10:58','',''),
('5','wspkkptesting@gmail.com','jasminderwsp@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">829160</strong><br><br><br>Thanks','','2022-11-30 9:11:09','',''),
('6','wspkkptesting@gmail.com','jasminderwsp@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">217985</strong><br><br><br>Thanks','','2022-11-30 9:12:05','',''),
('7','wspkkptesting@gmail.com','jasminderwsp@gmail.com','Password Reset Successul','Sent','Hello , <br> Your request for forgot password is successful.<br><br><br>Thanks','','2022-11-30 9:12:25','',''),
('8','wspkkptesting@gmail.com','manavsingh839@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">316222</strong><br><br><br>Thanks','','2022-11-30 9:16:14','',''),
('9','wspkkptesting@gmail.com','manavsingh839@gmail.com','Password Reset Successul','Sent','Hello , <br> Your request for forgot password is successful.<br><br><br>Thanks','','2022-11-30 9:50:46','',''),
('10','wspkkptesting@gmail.com','manavsingh839@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">795834</strong><br><br><br>Thanks','','2022-11-30 11:56:17','',''),
('11','wspkkptesting@gmail.com','manavsingh839@gmail.com','Password Reset Successul','Sent','Hello , <br> Your request for forgot password is successful.<br><br><br>Thanks','','2022-11-30 11:56:46','',''),
('12','wspkkptesting@gmail.com','manavsingh839@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">858868</strong><br><br><br>Thanks','','2022-12-13 9:31:15','',''),
('13','wspkkptesting@gmail.com','manavsingh839@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">077846</strong><br><br><br>Thanks','','2022-12-13 9:32:27','',''),
('14','wspkkptesting@gmail.com','manavsingh839@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">929749</strong><br><br><br>Thanks','','2022-12-13 9:36:58','',''),
('15','wspkkptesting@gmail.com','manavsingh839@gmail.com','Forgot Password Request','Sent','Hello , <br> You have requested a forgot password request . <br /><strong>Please copy and paste or fill the following code. <strong><br> <br> \r\n			<strong style=\"font-size:20px\">548722</strong><br><br><br>Thanks','','2022-12-13 9:55:08','',''),
('16','wspkkptesting@gmail.com','manavsingh839@gmail.com','Password Reset Successul','Sent','Hello , <br> Your request for forgot password is successful.<br><br><br>Thanks','','2022-12-13 9:56:26','',''); 


DROP TABLE IF EXISTS `file_upload`;
CREATE TABLE `file_upload` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `file_upload_identifier` text NOT NULL,
  `file_upload_file_name` text NOT NULL,
  `file_upload_insert_author` text NOT NULL,
  `file_upload_input_name` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `file_upload` VALUES ('1','upload_5fdf5ba14cbf97062','upload_5fdf5ba14cbf97062_logo.png','15','branding_logo','2020-12-20 15:11:45',''),
('4','upload_63888a7b082fd7811','upload_63888a7b082fd7811_group_2_(2).png','15','branding_logo','2022-12-01 11:05:31',''); 


DROP TABLE IF EXISTS `notify`;
CREATE TABLE `notify` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `notify_user_id` text NOT NULL,
  `notify_party_size` text NOT NULL,
  `notify_reminder_status` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `notify_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `notify` VALUES ('1','24','2','pending','2022-12-01 10:45:53','2022-12-01 10:45:53','24'),
('2','24','2','pending','2022-12-01 11:02:14','2022-12-01 11:02:14','24'),
('3','24','3','pending','2022-12-01 11:02:46','2022-12-01 11:02:46','24'),
('4','24','4','pending','2022-12-01 11:02:51','2022-12-01 11:02:51','24'),
('5','24','2','pending','2022-12-01 11:59:00','2022-12-01 11:59:00','24'),
('6','24','','pending','2022-12-01 11:59:57','2022-12-01 11:59:57','24'),
('7','24','pending','pending','2022-12-01 12:01:25','2022-12-01 12:01:25','24'),
('8','16','2','pending','2022-12-01 12:37:33','2022-12-01 12:37:33','16'),
('9','16','2','pending','2022-12-01 12:44:04','2022-12-01 12:44:04','16'),
('10','16','2','pending','2022-12-01 12:44:15','2022-12-01 12:44:15','16'),
('11','16','3','pending','2022-12-01 12:47:52','2022-12-01 12:47:52','16'),
('12','18','3','pending','2022-12-01 13:36:19','2022-12-01 13:36:19','18'),
('13','18','2','pending','2022-12-01 16:11:58','2022-12-01 16:11:58','18'),
('14','27','3','pending','2022-12-06 11:19:31','2022-12-06 11:19:31','27'),
('15','19','3','pending','2022-12-10 10:04:55','2022-12-10 10:04:55','19'),
('16','28','2','pending','2022-12-13 18:02:59','2022-12-13 18:02:59','28'),
('17','28','3','pending','2022-12-13 18:03:09','2022-12-13 18:03:09','28'),
('18','30','3','pending','2022-12-16 11:25:49','2022-12-16 11:25:49','30'),
('19','32','2','pending','2022-12-16 16:41:49','2022-12-16 16:41:49','32'); 


DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `setting_name` text NOT NULL,
  `setting_value` text NOT NULL,
  `setting_category` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `setting_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `template`;
CREATE TABLE `template` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `template_mail_title` text NOT NULL,
  `template_mail_content` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `template_insert_author` text NOT NULL,
  `template_editor_content` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `trash`;
CREATE TABLE `trash` (
  `record_id` int(255) NOT NULL AUTO_INCREMENT,
  `trash_record_type` text NOT NULL,
  `trash_record_id` text NOT NULL,
  `trash_record_data` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `trash_insert_author` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;

INSERT INTO `trash` VALUES ('1','users','16','a:24:{s:2:\"id\";s:2:\"16\";s:4:\"user\";s:6:\"tetete\";s:11:\"user_author\";s:2:\"16\";s:5:\"email\";s:11:\"tete@gm.com\";s:8:\"password\";s:60:\"$2y$10$9Trw8.uhxO9KnnKSUhP6VePdIyhUuXpa1.3FGREs.vVhEtEUUwuOW\";s:4:\"role\";s:7:\"teacher\";s:12:\"display_name\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"auth_token\";s:0:\"\";s:11:\"reset_token\";s:0:\"\";s:12:\"access_token\";s:0:\"\";s:3:\"otp\";s:0:\"\";s:8:\"verified\";s:1:\"0\";s:23:\"email_verification_code\";s:0:\"\";s:10:\"created_at\";s:19:\"2022-03-01 21:42:05\";s:9:\"user_name\";s:3:\"tet\";s:15:\"user_contact_no\";s:0:\"\";s:12:\"user_address\";s:0:\"\";s:11:\"user_status\";s:6:\"active\";s:12:\"date_created\";s:19:\"2022-03-01 17:12:05\";s:12:\"date_updated\";s:19:\"2022-03-01 17:12:05\";s:11:\"user_school\";s:0:\"\";s:19:\"user_school_address\";s:0:\"\";s:22:\"user_school_contact_no\";s:0:\"\";}','2022-03-01 17:12:48','2022-03-01 17:12:48','15'),
('2','audio','1','a:8:{s:9:\"record_id\";s:1:\"1\";s:11:\"audio_title\";s:26:\"Studey Trick for UPSC Exam\";s:16:\"audio_youtube_id\";s:11:\"L8_YWGnFWIM\";s:10:\"audio_file\";s:3:\"dsa\";s:12:\"audio_status\";s:6:\"active\";s:12:\"date_created\";s:19:\"2022-03-01 16:05:07\";s:12:\"date_updated\";s:19:\"2022-03-01 16:14:23\";s:19:\"audio_insert_author\";s:2:\"15\";}','2022-03-22 9:35:20','2022-03-22 9:35:20','15'),
('3','users','16','a:24:{s:2:\"id\";s:2:\"16\";s:4:\"user\";s:20:\"ullamco_voluptatem_c\";s:11:\"user_author\";s:2:\"16\";s:5:\"email\";s:24:\"hixotelyt@mailinator.com\";s:8:\"password\";s:60:\"$2y$10$lkZCgfsTjFwufpxJTNvl0uLNU7qOf6LmYc4rcLWdA09ei682pWd5K\";s:4:\"role\";s:4:\"user\";s:12:\"display_name\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"auth_token\";s:0:\"\";s:11:\"reset_token\";s:0:\"\";s:12:\"access_token\";s:0:\"\";s:3:\"otp\";s:0:\"\";s:8:\"verified\";s:1:\"0\";s:23:\"email_verification_code\";s:0:\"\";s:10:\"created_at\";s:19:\"2022-07-07 21:17:42\";s:9:\"user_name\";s:8:\"qahasofo\";s:15:\"user_contact_no\";s:2:\"16\";s:12:\"user_address\";s:20:\"Minima quae incididu\";s:11:\"user_status\";s:8:\"disabled\";s:12:\"date_created\";s:19:\"2022-07-07 17:47:42\";s:12:\"date_updated\";s:19:\"2022-07-07 17:47:42\";s:11:\"user_school\";s:0:\"\";s:19:\"user_school_address\";s:0:\"\";s:22:\"user_school_contact_no\";s:0:\"\";}','2022-07-07 17:47:50','2022-07-07 17:47:50','15'),
('4','booking','6','a:8:{s:9:\"record_id\";s:1:\"6\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:37:11\";s:12:\"date_updated\";s:18:\"2022-11-24 9:37:11\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('5','booking','5','a:8:{s:9:\"record_id\";s:1:\"5\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:34:22\";s:12:\"date_updated\";s:18:\"2022-11-24 9:34:22\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('6','booking','4','a:8:{s:9:\"record_id\";s:1:\"4\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:33:59\";s:12:\"date_updated\";s:18:\"2022-11-24 9:33:59\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('7','booking','3','a:8:{s:9:\"record_id\";s:1:\"3\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:13:19\";s:12:\"date_updated\";s:18:\"2022-11-24 9:13:19\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('8','booking','2','a:8:{s:9:\"record_id\";s:1:\"2\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:2:\"12\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:18:\"2022-11-24 9:10:18\";s:12:\"date_updated\";s:18:\"2022-11-24 9:10:18\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('9','booking','1','a:8:{s:9:\"record_id\";s:1:\"1\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:1:\"2\";s:18:\"booking_visit_time\";s:4:\"8:15\";s:15:\"booking_user_id\";s:1:\"2\";s:12:\"date_created\";s:18:\"2022-11-24 8:34:55\";s:12:\"date_updated\";s:18:\"2022-11-24 8:35:03\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 9:54:06','2022-11-24 9:54:06','15'),
('10','booking','17','a:8:{s:9:\"record_id\";s:2:\"17\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 10:21:11\";s:12:\"date_updated\";s:19:\"2022-11-24 10:21:11\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('11','booking','16','a:8:{s:9:\"record_id\";s:2:\"16\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:9:\"123213213\";s:12:\"date_created\";s:19:\"2022-11-24 10:18:33\";s:12:\"date_updated\";s:19:\"2022-11-24 10:18:33\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('12','booking','15','a:8:{s:9:\"record_id\";s:2:\"15\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:16:40\";s:12:\"date_updated\";s:19:\"2022-11-24 10:16:40\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('13','booking','14','a:8:{s:9:\"record_id\";s:2:\"14\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:15:35\";s:12:\"date_updated\";s:19:\"2022-11-24 10:15:35\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('14','booking','13','a:8:{s:9:\"record_id\";s:2:\"13\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:05:50\";s:12:\"date_updated\";s:19:\"2022-11-24 10:05:50\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('15','booking','12','a:8:{s:9:\"record_id\";s:2:\"12\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:5:\"45345\";s:12:\"date_created\";s:19:\"2022-11-24 10:04:46\";s:12:\"date_updated\";s:19:\"2022-11-24 10:04:46\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('16','booking','11','a:8:{s:9:\"record_id\";s:2:\"11\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:03:24\";s:12:\"date_updated\";s:19:\"2022-11-24 10:03:24\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('17','booking','10','a:8:{s:9:\"record_id\";s:2:\"10\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:0:\"\";s:12:\"date_created\";s:19:\"2022-11-24 10:02:23\";s:12:\"date_updated\";s:19:\"2022-11-24 10:02:23\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('18','booking','9','a:8:{s:9:\"record_id\";s:1:\"9\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:2:\"13\";s:12:\"date_created\";s:19:\"2022-11-24 10:01:23\";s:12:\"date_updated\";s:19:\"2022-11-24 10:01:23\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('19','booking','8','a:8:{s:9:\"record_id\";s:1:\"8\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:1:\"2\";s:12:\"date_created\";s:18:\"2022-11-24 9:58:49\";s:12:\"date_updated\";s:18:\"2022-11-24 9:58:49\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('20','booking','7','a:8:{s:9:\"record_id\";s:1:\"7\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:0:\"\";s:15:\"booking_user_id\";s:1:\"1\";s:12:\"date_created\";s:18:\"2022-11-24 9:58:37\";s:12:\"date_updated\";s:18:\"2022-11-24 9:58:37\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:09:43','2022-11-24 11:09:43','15'),
('21','booking','21','a:8:{s:9:\"record_id\";s:2:\"21\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"00:09\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:10:59\";s:12:\"date_updated\";s:19:\"2022-11-24 11:10:59\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:11:21','2022-11-24 11:11:21','15'),
('22','booking','20','a:8:{s:9:\"record_id\";s:2:\"20\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:10:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:10:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:11:21','2022-11-24 11:11:21','15'),
('23','booking','19','a:8:{s:9:\"record_id\";s:2:\"19\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:10:07\";s:12:\"date_updated\";s:19:\"2022-11-24 11:10:07\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:11:21','2022-11-24 11:11:21','15'),
('24','booking','18','a:8:{s:9:\"record_id\";s:2:\"18\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:09:52\";s:12:\"date_updated\";s:19:\"2022-11-24 11:09:52\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:11:21','2022-11-24 11:11:21','15'),
('25','booking','25','a:8:{s:9:\"record_id\";s:2:\"25\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:17:36\";s:12:\"date_updated\";s:19:\"2022-11-24 11:17:36\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:19:18','2022-11-24 11:19:18','15'),
('26','booking','24','a:8:{s:9:\"record_id\";s:2:\"24\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:14:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:14:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:19:18','2022-11-24 11:19:18','15'),
('27','booking','23','a:8:{s:9:\"record_id\";s:2:\"23\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:14:48\";s:12:\"date_updated\";s:19:\"2022-11-24 11:14:48\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:19:18','2022-11-24 11:19:18','15'),
('28','booking','22','a:8:{s:9:\"record_id\";s:2:\"22\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:14:29\";s:12:\"date_updated\";s:19:\"2022-11-24 11:14:29\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:19:18','2022-11-24 11:19:18','15'),
('29','booking','28','a:8:{s:9:\"record_id\";s:2:\"28\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:19:37\";s:12:\"date_updated\";s:19:\"2022-11-24 11:19:37\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:20:52','2022-11-24 11:20:52','15'),
('30','booking','27','a:8:{s:9:\"record_id\";s:2:\"27\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:19:29\";s:12:\"date_updated\";s:19:\"2022-11-24 11:19:29\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:20:52','2022-11-24 11:20:52','15'),
('31','booking','26','a:8:{s:9:\"record_id\";s:2:\"26\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:19:21\";s:12:\"date_updated\";s:19:\"2022-11-24 11:19:21\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:20:52','2022-11-24 11:20:52','15'),
('32','booking','31','a:8:{s:9:\"record_id\";s:2:\"31\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:21:32\";s:12:\"date_updated\";s:19:\"2022-11-24 11:21:32\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:35','2022-11-24 11:22:35','15'),
('33','booking','30','a:8:{s:9:\"record_id\";s:2:\"30\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:21:14\";s:12:\"date_updated\";s:19:\"2022-11-24 11:21:14\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:35','2022-11-24 11:22:35','15'),
('34','booking','29','a:8:{s:9:\"record_id\";s:2:\"29\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:20:58\";s:12:\"date_updated\";s:19:\"2022-11-24 11:20:58\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:35','2022-11-24 11:22:35','15'),
('35','booking','33','a:8:{s:9:\"record_id\";s:2:\"33\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:10\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:22:38\";s:12:\"date_updated\";s:19:\"2022-11-24 11:22:38\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:51','2022-11-24 11:22:51','15'),
('36','booking','32','a:8:{s:9:\"record_id\";s:2:\"32\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:21:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:21:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:22:51','2022-11-24 11:22:51','15'),
('37','booking','36','a:8:{s:9:\"record_id\";s:2:\"36\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:23:09\";s:12:\"date_updated\";s:19:\"2022-11-24 11:23:09\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:24:25','2022-11-24 11:24:25','15'),
('38','booking','35','a:8:{s:9:\"record_id\";s:2:\"35\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:23:03\";s:12:\"date_updated\";s:19:\"2022-11-24 11:23:03\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:24:25','2022-11-24 11:24:25','15'),
('39','booking','34','a:8:{s:9:\"record_id\";s:2:\"34\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:22:58\";s:12:\"date_updated\";s:19:\"2022-11-24 11:22:58\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:24:25','2022-11-24 11:24:25','15'),
('40','booking','37','a:8:{s:9:\"record_id\";s:2:\"37\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:23:34\";s:12:\"date_updated\";s:19:\"2022-11-24 11:23:34\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:24:39','2022-11-24 11:24:39','15'),
('41','booking','41','a:8:{s:9:\"record_id\";s:2:\"41\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:25:51\";s:12:\"date_updated\";s:19:\"2022-11-24 11:25:51\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:26:43','2022-11-24 11:26:43','15'),
('42','booking','40','a:8:{s:9:\"record_id\";s:2:\"40\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:25:25\";s:12:\"date_updated\";s:19:\"2022-11-24 11:25:25\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:26:43','2022-11-24 11:26:43','15'),
('43','booking','39','a:8:{s:9:\"record_id\";s:2:\"39\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:25:04\";s:12:\"date_updated\";s:19:\"2022-11-24 11:25:04\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:26:43','2022-11-24 11:26:43','15'),
('44','booking','38','a:8:{s:9:\"record_id\";s:2:\"38\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:24:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:24:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:26:43','2022-11-24 11:26:43','15'),
('45','booking','44','a:8:{s:9:\"record_id\";s:2:\"44\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:27:38\";s:12:\"date_updated\";s:19:\"2022-11-24 11:27:38\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:34:36','2022-11-24 11:34:36','15'),
('46','booking','43','a:8:{s:9:\"record_id\";s:2:\"43\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:27:09\";s:12:\"date_updated\";s:19:\"2022-11-24 11:27:09\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:34:36','2022-11-24 11:34:36','15'),
('47','booking','42','a:8:{s:9:\"record_id\";s:2:\"42\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:27:04\";s:12:\"date_updated\";s:19:\"2022-11-24 11:27:04\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:34:36','2022-11-24 11:34:36','15'),
('48','booking','50','a:8:{s:9:\"record_id\";s:2:\"50\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:37:47\";s:12:\"date_updated\";s:19:\"2022-11-24 11:37:47\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:38:16','2022-11-24 11:38:16','15'),
('49','booking','49','a:8:{s:9:\"record_id\";s:2:\"49\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:37:37\";s:12:\"date_updated\";s:19:\"2022-11-24 11:37:37\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:38:16','2022-11-24 11:38:16','15'),
('50','booking','48','a:8:{s:9:\"record_id\";s:2:\"48\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:37:29\";s:12:\"date_updated\";s:19:\"2022-11-24 11:37:29\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:38:16','2022-11-24 11:38:16','15'),
('51','booking','53','a:8:{s:9:\"record_id\";s:2:\"53\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:38:32\";s:12:\"date_updated\";s:19:\"2022-11-24 11:38:32\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:46:37','2022-11-24 11:46:37','15'),
('52','booking','52','a:8:{s:9:\"record_id\";s:2:\"52\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:38:26\";s:12:\"date_updated\";s:19:\"2022-11-24 11:38:26\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:46:37','2022-11-24 11:46:37','15'),
('53','booking','51','a:8:{s:9:\"record_id\";s:2:\"51\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:38:19\";s:12:\"date_updated\";s:19:\"2022-11-24 11:38:19\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 11:46:37','2022-11-24 11:46:37','15'),
('54','booking','61','a:8:{s:9:\"record_id\";s:2:\"61\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:58:47\";s:12:\"date_updated\";s:19:\"2022-11-24 11:58:47\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 12:58:27','2022-11-24 12:58:27','15'),
('55','booking','60','a:8:{s:9:\"record_id\";s:2:\"60\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:15\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:50:58\";s:12:\"date_updated\";s:19:\"2022-11-24 11:50:58\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 12:58:27','2022-11-24 12:58:27','15'),
('56','booking','59','a:8:{s:9:\"record_id\";s:2:\"59\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:20\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:47:25\";s:12:\"date_updated\";s:19:\"2022-11-24 11:47:25\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 12:58:27','2022-11-24 12:58:27','15'),
('57','booking','58','a:8:{s:9:\"record_id\";s:2:\"58\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:10\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:47:15\";s:12:\"date_updated\";s:19:\"2022-11-24 11:47:15\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 12:58:27','2022-11-24 12:58:27','15'),
('58','booking','57','a:8:{s:9:\"record_id\";s:2:\"57\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:47:10\";s:12:\"date_updated\";s:19:\"2022-11-24 11:47:10\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 12:58:27','2022-11-24 12:58:27','15'),
('59','booking','56','a:8:{s:9:\"record_id\";s:2:\"56\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:10\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:46:54\";s:12:\"date_updated\";s:19:\"2022-11-24 11:46:54\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 12:58:27','2022-11-24 12:58:27','15'),
('60','booking','55','a:8:{s:9:\"record_id\";s:2:\"55\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:46:49\";s:12:\"date_updated\";s:19:\"2022-11-24 11:46:49\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 12:58:27','2022-11-24 12:58:27','15'),
('61','booking','54','a:8:{s:9:\"record_id\";s:2:\"54\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 11:46:42\";s:12:\"date_updated\";s:19:\"2022-11-24 11:46:42\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-24 12:58:27','2022-11-24 12:58:27','15'),
('62','booking','65','a:8:{s:9:\"record_id\";s:2:\"65\";s:15:\"booking_desk_id\";s:1:\"3\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 12:58:50\";s:12:\"date_updated\";s:19:\"2022-11-24 12:58:50\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-25 10:33:09','2022-11-25 10:33:09','15'),
('63','booking','64','a:8:{s:9:\"record_id\";s:2:\"64\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:10\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 12:58:44\";s:12:\"date_updated\";s:19:\"2022-11-24 12:58:44\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-25 10:33:09','2022-11-25 10:33:09','15'),
('64','booking','63','a:8:{s:9:\"record_id\";s:2:\"63\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 12:58:40\";s:12:\"date_updated\";s:19:\"2022-11-24 12:58:40\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-25 10:33:10','2022-11-25 10:33:10','15'),
('65','booking','62','a:8:{s:9:\"record_id\";s:2:\"62\";s:15:\"booking_desk_id\";s:1:\"1\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-24 12:58:35\";s:12:\"date_updated\";s:19:\"2022-11-24 12:58:35\";s:21:\"booking_insert_author\";s:2:\"15\";}','2022-11-25 10:33:10','2022-11-25 10:33:10','15'),
('66','desk','3','a:7:{s:9:\"record_id\";s:1:\"3\";s:9:\"desk_size\";s:9:\"8_persons\";s:9:\"desk_time\";s:2:\"15\";s:10:\"desk_count\";s:2:\"10\";s:12:\"date_created\";s:18:\"2022-11-24 8:24:39\";s:12:\"date_updated\";s:19:\"2022-11-24 10:04:36\";s:18:\"desk_insert_author\";s:2:\"15\";}','2022-11-25 10:33:17','2022-11-25 10:33:17','15'),
('67','desk','2','a:7:{s:9:\"record_id\";s:1:\"2\";s:9:\"desk_size\";s:9:\"4_persons\";s:9:\"desk_time\";s:2:\"10\";s:10:\"desk_count\";s:1:\"3\";s:12:\"date_created\";s:18:\"2022-11-24 8:24:25\";s:12:\"date_updated\";s:19:\"2022-11-24 11:48:07\";s:18:\"desk_insert_author\";s:2:\"15\";}','2022-11-25 10:33:17','2022-11-25 10:33:17','15'),
('68','desk','1','a:7:{s:9:\"record_id\";s:1:\"1\";s:9:\"desk_size\";s:9:\"2_persons\";s:9:\"desk_time\";s:1:\"5\";s:10:\"desk_count\";s:1:\"3\";s:12:\"date_created\";s:18:\"2022-11-24 8:24:00\";s:12:\"date_updated\";s:19:\"2022-11-24 12:59:04\";s:18:\"desk_insert_author\";s:2:\"15\";}','2022-11-25 10:33:17','2022-11-25 10:33:17','15'),
('69','booking','77','a:9:{s:9:\"record_id\";s:2:\"77\";s:15:\"booking_desk_id\";s:1:\"6\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"16\";s:12:\"date_created\";s:19:\"2022-11-25 12:06:26\";s:12:\"date_updated\";s:19:\"2022-11-25 12:06:26\";s:21:\"booking_insert_author\";s:2:\"16\";s:28:\"booking_special_requirements\";s:13:\" requirements\";}','2022-11-29 10:29:28','2022-11-29 10:29:28','15'),
('70','booking','76','a:9:{s:9:\"record_id\";s:2:\"76\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:45\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 12:00:27\";s:12:\"date_updated\";s:19:\"2022-11-25 12:00:27\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:28','2022-11-29 10:29:28','15'),
('71','booking','75','a:9:{s:9:\"record_id\";s:2:\"75\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:40\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 11:55:23\";s:12:\"date_updated\";s:19:\"2022-11-25 11:55:23\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('72','booking','74','a:9:{s:9:\"record_id\";s:2:\"74\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:35\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 11:51:47\";s:12:\"date_updated\";s:19:\"2022-11-25 11:51:47\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('73','booking','73','a:9:{s:9:\"record_id\";s:2:\"73\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:30\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 11:47:22\";s:12:\"date_updated\";s:19:\"2022-11-25 11:47:22\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('74','booking','72','a:9:{s:9:\"record_id\";s:2:\"72\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:25\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 11:46:28\";s:12:\"date_updated\";s:19:\"2022-11-25 11:46:28\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('75','booking','71','a:9:{s:9:\"record_id\";s:2:\"71\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:20\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 11:44:14\";s:12:\"date_updated\";s:19:\"2022-11-25 11:44:14\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('76','booking','70','a:9:{s:9:\"record_id\";s:2:\"70\";s:15:\"booking_desk_id\";s:1:\"5\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"16\";s:12:\"date_created\";s:19:\"2022-11-25 11:31:05\";s:12:\"date_updated\";s:19:\"2022-11-25 11:31:05\";s:21:\"booking_insert_author\";s:2:\"16\";s:28:\"booking_special_requirements\";s:7:\"message\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('77','booking','69','a:9:{s:9:\"record_id\";s:2:\"69\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:15\";s:15:\"booking_user_id\";s:2:\"16\";s:12:\"date_created\";s:19:\"2022-11-25 11:05:31\";s:12:\"date_updated\";s:19:\"2022-11-25 11:05:31\";s:21:\"booking_insert_author\";s:2:\"16\";s:28:\"booking_special_requirements\";s:8:\"surprise\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('78','booking','68','a:9:{s:9:\"record_id\";s:2:\"68\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:10\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 10:41:54\";s:12:\"date_updated\";s:19:\"2022-11-25 10:41:54\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('79','booking','67','a:9:{s:9:\"record_id\";s:2:\"67\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 10:41:43\";s:12:\"date_updated\";s:19:\"2022-11-25 10:41:43\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('80','booking','66','a:9:{s:9:\"record_id\";s:2:\"66\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-11-25 10:41:30\";s:12:\"date_updated\";s:19:\"2022-11-25 10:41:30\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:0:\"\";}','2022-11-29 10:29:29','2022-11-29 10:29:29','15'),
('81','desk','10','a:7:{s:9:\"record_id\";s:2:\"10\";s:9:\"desk_size\";s:1:\"8\";s:9:\"desk_time\";s:2:\"15\";s:10:\"desk_count\";s:2:\"10\";s:12:\"date_created\";s:19:\"2022-11-25 10:35:07\";s:12:\"date_updated\";s:19:\"2022-11-25 10:35:07\";s:18:\"desk_insert_author\";s:2:\"15\";}','2022-11-29 10:43:27','2022-11-29 10:43:27','15'),
('82','desk','9','a:7:{s:9:\"record_id\";s:1:\"9\";s:9:\"desk_size\";s:1:\"7\";s:9:\"desk_time\";s:2:\"15\";s:10:\"desk_count\";s:2:\"10\";s:12:\"date_created\";s:19:\"2022-11-25 10:34:58\";s:12:\"date_updated\";s:19:\"2022-11-25 10:34:58\";s:18:\"desk_insert_author\";s:2:\"15\";}','2022-11-29 10:43:35','2022-11-29 10:43:35','15'),
('83','desk','8','a:7:{s:9:\"record_id\";s:1:\"8\";s:9:\"desk_size\";s:1:\"6\";s:9:\"desk_time\";s:2:\"15\";s:10:\"desk_count\";s:2:\"10\";s:12:\"date_created\";s:19:\"2022-11-25 10:34:50\";s:12:\"date_updated\";s:19:\"2022-11-25 10:34:50\";s:18:\"desk_insert_author\";s:2:\"15\";}','2022-11-29 10:43:35','2022-11-29 10:43:35','15'),
('84','booking','85','a:11:{s:9:\"record_id\";s:2:\"85\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 10:42:23\";s:12:\"date_updated\";s:19:\"2022-11-30 10:42:23\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 10:55:44','2022-11-30 10:55:44','15'),
('85','booking','84','a:11:{s:9:\"record_id\";s:2:\"84\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 10:12:44\";s:12:\"date_updated\";s:19:\"2022-11-30 10:12:44\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 10:55:44','2022-11-30 10:55:44','15'),
('86','booking','83','a:11:{s:9:\"record_id\";s:2:\"83\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:18:\"2022-11-30 9:21:23\";s:12:\"date_updated\";s:19:\"2022-11-30 10:02:54\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Cancelled\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 10:55:44','2022-11-30 10:55:44','15'),
('87','booking','82','a:11:{s:9:\"record_id\";s:2:\"82\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:18:\"2022-11-30 9:21:15\";s:12:\"date_updated\";s:18:\"2022-11-30 9:21:15\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 10:55:44','2022-11-30 10:55:44','15'),
('88','booking','81','a:11:{s:9:\"record_id\";s:2:\"81\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:05\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:18:\"2022-11-30 9:20:51\";s:12:\"date_updated\";s:18:\"2022-11-30 9:20:51\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 10:55:44','2022-11-30 10:55:44','15'),
('89','booking','80','a:11:{s:9:\"record_id\";s:2:\"80\";s:15:\"booking_desk_id\";s:1:\"4\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"16\";s:12:\"date_created\";s:19:\"2022-11-29 10:52:43\";s:12:\"date_updated\";s:19:\"2022-11-29 10:52:43\";s:21:\"booking_insert_author\";s:2:\"16\";s:28:\"booking_special_requirements\";s:8:\"surprise\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 10:55:45','2022-11-30 10:55:45','15'),
('90','booking','79','a:11:{s:9:\"record_id\";s:2:\"79\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"18\";s:12:\"date_created\";s:19:\"2022-11-29 10:51:33\";s:12:\"date_updated\";s:19:\"2022-11-29 10:51:33\";s:21:\"booking_insert_author\";s:2:\"18\";s:28:\"booking_special_requirements\";s:0:\"\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 10:55:45','2022-11-30 10:55:45','15'),
('91','booking','78','a:11:{s:9:\"record_id\";s:2:\"78\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"18\";s:12:\"date_created\";s:19:\"2022-11-29 10:50:41\";s:12:\"date_updated\";s:19:\"2022-11-29 10:50:41\";s:21:\"booking_insert_author\";s:2:\"18\";s:28:\"booking_special_requirements\";s:0:\"\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 10:55:46','2022-11-30 10:55:46','15'),
('92','booking','86','a:11:{s:9:\"record_id\";s:2:\"86\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"20:00\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 10:56:17\";s:12:\"date_updated\";s:19:\"2022-11-30 10:56:17\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 10:57:03','2022-11-30 10:57:03','15'),
('93','booking','87','a:11:{s:9:\"record_id\";s:2:\"87\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"20:00\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 10:57:13\";s:12:\"date_updated\";s:19:\"2022-11-30 10:57:13\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 10:58:18','2022-11-30 10:58:18','15'),
('94','booking','95','a:11:{s:9:\"record_id\";s:2:\"95\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:8:\"00:05 am\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:27:20\";s:12:\"date_updated\";s:19:\"2022-11-30 11:27:20\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:27:33','2022-11-30 11:27:33','15'),
('95','booking','94','a:11:{s:9:\"record_id\";s:2:\"94\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:10:\"2022-11-30\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:20:01\";s:12:\"date_updated\";s:19:\"2022-11-30 11:20:01\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:27:33','2022-11-30 11:27:33','15'),
('96','booking','93','a:11:{s:9:\"record_id\";s:2:\"93\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:10:\"2022-11-30\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:16:58\";s:12:\"date_updated\";s:19:\"2022-11-30 11:16:58\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:27:33','2022-11-30 11:27:33','15'),
('97','booking','92','a:11:{s:9:\"record_id\";s:2:\"92\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:10:\"2022-11-30\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:16:37\";s:12:\"date_updated\";s:19:\"2022-11-30 11:16:37\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:27:33','2022-11-30 11:27:33','15'),
('98','booking','91','a:11:{s:9:\"record_id\";s:2:\"91\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:16:32\";s:12:\"date_updated\";s:19:\"2022-11-30 11:16:32\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 11:27:33','2022-11-30 11:27:33','15'),
('99','booking','90','a:11:{s:9:\"record_id\";s:2:\"90\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:06:53\";s:12:\"date_updated\";s:19:\"2022-11-30 11:06:53\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 11:27:33','2022-11-30 11:27:33','15'),
('100','booking','89','a:11:{s:9:\"record_id\";s:2:\"89\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:10:\"2022-11-30\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 10:58:49\";s:12:\"date_updated\";s:19:\"2022-11-30 10:58:49\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:27:33','2022-11-30 11:27:33','15'),
('101','booking','88','a:11:{s:9:\"record_id\";s:2:\"88\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"20:00\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 10:58:34\";s:12:\"date_updated\";s:19:\"2022-11-30 10:58:34\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:27:33','2022-11-30 11:27:33','15'),
('102','booking','97','a:11:{s:9:\"record_id\";s:2:\"97\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:8:\"20:05 pm\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:27:50\";s:12:\"date_updated\";s:19:\"2022-11-30 11:27:50\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:30:41','2022-11-30 11:30:41','15'),
('103','booking','96','a:11:{s:9:\"record_id\";s:2:\"96\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"20:00\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:27:44\";s:12:\"date_updated\";s:19:\"2022-11-30 11:27:44\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:30:41','2022-11-30 11:30:41','15'),
('104','booking','104','a:11:{s:9:\"record_id\";s:3:\"104\";s:15:\"booking_desk_id\";s:0:\"\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:8:\"08:30 pm\";s:15:\"booking_user_id\";s:2:\"24\";s:12:\"date_created\";s:19:\"2022-11-30 11:48:48\";s:12:\"date_updated\";s:19:\"2022-11-30 11:48:48\";s:21:\"booking_insert_author\";s:2:\"24\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";}','2022-11-30 11:48:56','2022-11-30 11:48:56','15'),
('105','booking','105','a:11:{s:9:\"record_id\";s:3:\"105\";s:15:\"booking_desk_id\";s:1:\"2\";s:18:\"booking_desk_count\";s:0:\"\";s:18:\"booking_visit_time\";s:5:\"08:00\";s:15:\"booking_user_id\";s:2:\"16\";s:12:\"date_created\";s:19:\"2022-11-30 11:52:34\";s:12:\"date_updated\";s:19:\"2022-11-30 11:52:34\";s:21:\"booking_insert_author\";s:2:\"16\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:0:\"\";s:18:\"booking_party_size\";s:0:\"\";}','2022-11-30 11:54:53','2022-11-30 11:54:53','15'),
('106','booking','122','a:10:{s:9:\"record_id\";s:3:\"122\";s:18:\"booking_visit_time\";s:8:\"06:20 am\";s:15:\"booking_user_id\";s:2:\"24\";s:12:\"date_created\";s:19:\"2022-12-01 10:27:09\";s:12:\"date_updated\";s:19:\"2022-12-01 14:43:18\";s:21:\"booking_insert_author\";s:2:\"24\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:6:\"Seated\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:52','2022-12-01 14:43:52','15'),
('107','booking','121','a:10:{s:9:\"record_id\";s:3:\"121\";s:18:\"booking_visit_time\";s:8:\"06:15 am\";s:15:\"booking_user_id\";s:2:\"24\";s:12:\"date_created\";s:19:\"2022-12-01 10:02:56\";s:12:\"date_updated\";s:19:\"2022-12-01 10:02:56\";s:21:\"booking_insert_author\";s:2:\"24\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:52','2022-12-01 14:43:52','15'),
('108','booking','120','a:10:{s:9:\"record_id\";s:3:\"120\";s:18:\"booking_visit_time\";s:8:\"08:00 pm\";s:15:\"booking_user_id\";s:2:\"18\";s:12:\"date_created\";s:18:\"2022-12-01 9:41:55\";s:12:\"date_updated\";s:18:\"2022-12-01 9:42:02\";s:21:\"booking_insert_author\";s:2:\"18\";s:28:\"booking_special_requirements\";s:0:\"\";s:14:\"booking_status\";s:9:\"Cancelled\";s:18:\"booking_party_size\";s:1:\"3\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:52','2022-12-01 14:43:52','15'),
('109','booking','119','a:10:{s:9:\"record_id\";s:3:\"119\";s:18:\"booking_visit_time\";s:8:\"06:10 am\";s:15:\"booking_user_id\";s:2:\"18\";s:12:\"date_created\";s:18:\"2022-12-01 9:40:57\";s:12:\"date_updated\";s:18:\"2022-12-01 9:41:04\";s:21:\"booking_insert_author\";s:2:\"18\";s:28:\"booking_special_requirements\";s:4:\"Test\";s:14:\"booking_status\";s:9:\"Cancelled\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('110','booking','118','a:10:{s:9:\"record_id\";s:3:\"118\";s:18:\"booking_visit_time\";s:8:\"08:05 pm\";s:15:\"booking_user_id\";s:2:\"26\";s:12:\"date_created\";s:18:\"2022-12-01 6:17:01\";s:12:\"date_updated\";s:18:\"2022-12-01 6:17:01\";s:21:\"booking_insert_author\";s:2:\"26\";s:28:\"booking_special_requirements\";s:0:\"\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"4\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('111','booking','117','a:10:{s:9:\"record_id\";s:3:\"117\";s:18:\"booking_visit_time\";s:8:\"08:00 pm\";s:15:\"booking_user_id\";s:2:\"18\";s:12:\"date_created\";s:18:\"2022-12-01 6:14:59\";s:12:\"date_updated\";s:18:\"2022-12-01 6:15:11\";s:21:\"booking_insert_author\";s:2:\"18\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Cancelled\";s:18:\"booking_party_size\";s:1:\"4\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('112','booking','116','a:10:{s:9:\"record_id\";s:3:\"116\";s:18:\"booking_visit_time\";s:8:\"06:05 am\";s:15:\"booking_user_id\";s:2:\"18\";s:12:\"date_created\";s:18:\"2022-12-01 6:14:12\";s:12:\"date_updated\";s:18:\"2022-12-01 6:14:25\";s:21:\"booking_insert_author\";s:2:\"18\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Cancelled\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('113','booking','115','a:10:{s:9:\"record_id\";s:3:\"115\";s:18:\"booking_visit_time\";s:8:\"06:00 am\";s:15:\"booking_user_id\";s:2:\"18\";s:12:\"date_created\";s:18:\"2022-12-01 6:13:20\";s:12:\"date_updated\";s:18:\"2022-12-01 6:14:00\";s:21:\"booking_insert_author\";s:2:\"18\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Cancelled\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('114','booking','114','a:10:{s:9:\"record_id\";s:3:\"114\";s:18:\"booking_visit_time\";s:8:\"09:05 pm\";s:15:\"booking_user_id\";s:2:\"24\";s:12:\"date_created\";s:19:\"2022-11-30 20:47:58\";s:12:\"date_updated\";s:19:\"2022-11-30 20:47:58\";s:21:\"booking_insert_author\";s:2:\"24\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('115','booking','113','a:10:{s:9:\"record_id\";s:3:\"113\";s:18:\"booking_visit_time\";s:8:\"09:00 pm\";s:15:\"booking_user_id\";s:2:\"26\";s:12:\"date_created\";s:19:\"2022-11-30 20:37:11\";s:12:\"date_updated\";s:19:\"2022-11-30 20:37:11\";s:21:\"booking_insert_author\";s:2:\"26\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('116','booking','112','a:10:{s:9:\"record_id\";s:3:\"112\";s:18:\"booking_visit_time\";s:8:\"08:00 pm\";s:15:\"booking_user_id\";s:2:\"24\";s:12:\"date_created\";s:19:\"2022-11-30 20:33:52\";s:12:\"date_updated\";s:19:\"2022-11-30 20:33:52\";s:21:\"booking_insert_author\";s:2:\"24\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"3\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('117','booking','111','a:10:{s:9:\"record_id\";s:3:\"111\";s:18:\"booking_visit_time\";s:8:\"08:55 pm\";s:15:\"booking_user_id\";s:2:\"24\";s:12:\"date_created\";s:19:\"2022-11-30 20:29:27\";s:12:\"date_updated\";s:19:\"2022-11-30 20:29:27\";s:21:\"booking_insert_author\";s:2:\"24\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('118','booking','110','a:10:{s:9:\"record_id\";s:3:\"110\";s:18:\"booking_visit_time\";s:8:\"08:50 pm\";s:15:\"booking_user_id\";s:2:\"24\";s:12:\"date_created\";s:19:\"2022-11-30 20:28:54\";s:12:\"date_updated\";s:19:\"2022-11-30 20:28:54\";s:21:\"booking_insert_author\";s:2:\"24\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('119','booking','109','a:10:{s:9:\"record_id\";s:3:\"109\";s:18:\"booking_visit_time\";s:8:\"08:45 pm\";s:15:\"booking_user_id\";s:2:\"24\";s:12:\"date_created\";s:19:\"2022-11-30 20:26:51\";s:12:\"date_updated\";s:19:\"2022-11-30 20:26:51\";s:21:\"booking_insert_author\";s:2:\"24\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('120','booking','108','a:10:{s:9:\"record_id\";s:3:\"108\";s:18:\"booking_visit_time\";s:8:\"08:40 pm\";s:15:\"booking_user_id\";s:2:\"26\";s:12:\"date_created\";s:19:\"2022-11-30 20:22:03\";s:12:\"date_updated\";s:19:\"2022-11-30 20:22:03\";s:21:\"booking_insert_author\";s:2:\"26\";s:28:\"booking_special_requirements\";s:0:\"\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('121','booking','107','a:10:{s:9:\"record_id\";s:3:\"107\";s:18:\"booking_visit_time\";s:8:\"08:35 pm\";s:15:\"booking_user_id\";s:2:\"26\";s:12:\"date_created\";s:19:\"2022-11-30 20:20:22\";s:12:\"date_updated\";s:19:\"2022-11-30 20:20:22\";s:21:\"booking_insert_author\";s:2:\"26\";s:28:\"booking_special_requirements\";s:0:\"\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('122','booking','106','a:10:{s:9:\"record_id\";s:3:\"106\";s:18:\"booking_visit_time\";s:8:\"08:30 pm\";s:15:\"booking_user_id\";s:2:\"16\";s:12:\"date_created\";s:19:\"2022-11-30 11:57:11\";s:12:\"date_updated\";s:19:\"2022-11-30 11:58:03\";s:21:\"booking_insert_author\";s:2:\"16\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Cancelled\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:53','2022-12-01 14:43:53','15'),
('123','booking','103','a:10:{s:9:\"record_id\";s:3:\"103\";s:18:\"booking_visit_time\";s:8:\"08:25 pm\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:43:01\";s:12:\"date_updated\";s:19:\"2022-11-30 11:43:01\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:54','2022-12-01 14:43:54','15'),
('124','booking','102','a:10:{s:9:\"record_id\";s:3:\"102\";s:18:\"booking_visit_time\";s:8:\"08:20 pm\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:38:53\";s:12:\"date_updated\";s:19:\"2022-11-30 11:38:53\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:54','2022-12-01 14:43:54','15'),
('125','booking','101','a:10:{s:9:\"record_id\";s:3:\"101\";s:18:\"booking_visit_time\";s:8:\"08:15 pm\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:38:25\";s:12:\"date_updated\";s:19:\"2022-11-30 11:38:25\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:54','2022-12-01 14:43:54','15'),
('126','booking','100','a:10:{s:9:\"record_id\";s:3:\"100\";s:18:\"booking_visit_time\";s:8:\"08:10 pm\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:37:38\";s:12:\"date_updated\";s:19:\"2022-11-30 11:37:38\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:58','2022-12-01 14:43:58','15'),
('127','booking','99','a:10:{s:9:\"record_id\";s:2:\"99\";s:18:\"booking_visit_time\";s:8:\"08:05 pm\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:33:23\";s:12:\"date_updated\";s:19:\"2022-11-30 11:33:23\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:58','2022-12-01 14:43:58','15'),
('128','booking','98','a:10:{s:9:\"record_id\";s:2:\"98\";s:18:\"booking_visit_time\";s:8:\"08:00 pm\";s:15:\"booking_user_id\";s:2:\"25\";s:12:\"date_created\";s:19:\"2022-11-30 11:31:21\";s:12:\"date_updated\";s:19:\"2022-11-30 11:31:21\";s:21:\"booking_insert_author\";s:2:\"25\";s:28:\"booking_special_requirements\";s:4:\"test\";s:14:\"booking_status\";s:9:\"Confirmed\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-01 14:43:58','2022-12-01 14:43:58','15'),
('129','booking','128','a:10:{s:9:\"record_id\";s:3:\"128\";s:18:\"booking_visit_time\";s:8:\"02:00 pm\";s:15:\"booking_user_id\";s:2:\"15\";s:12:\"date_created\";s:19:\"2022-12-18 14:08:37\";s:12:\"date_updated\";s:19:\"2022-12-18 14:08:50\";s:21:\"booking_insert_author\";s:2:\"15\";s:28:\"booking_special_requirements\";s:1:\"y\";s:14:\"booking_status\";s:9:\"Cancelled\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-18 14:31:36','2022-12-18 14:31:36','15'),
('130','booking','130','a:10:{s:9:\"record_id\";s:3:\"130\";s:18:\"booking_visit_time\";s:8:\"02:05 pm\";s:15:\"booking_user_id\";s:2:\"33\";s:12:\"date_created\";s:19:\"2022-12-18 19:48:57\";s:12:\"date_updated\";s:19:\"2022-12-18 19:48:57\";s:21:\"booking_insert_author\";s:2:\"33\";s:28:\"booking_special_requirements\";s:2:\"34\";s:14:\"booking_status\";s:7:\"Waiting\";s:18:\"booking_party_size\";s:1:\"2\";s:15:\"booking_remarks\";s:0:\"\";}','2022-12-18 19:56:38','2022-12-18 19:56:38','15'); 


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `user_author` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `display_name` text NOT NULL,
  `rights` text NOT NULL,
  `auth_token` varchar(255) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `access_token` varchar(255) NOT NULL COMMENT 'For mobile API',
  `otp` text NOT NULL,
  `verified` int(2) NOT NULL,
  `email_verification_code` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_name` text NOT NULL,
  `user_contact_no` text NOT NULL,
  `user_address` text NOT NULL,
  `user_status` text NOT NULL,
  `date_created` text NOT NULL,
  `date_updated` text NOT NULL,
  `user_school` text NOT NULL,
  `user_school_address` text NOT NULL,
  `user_school_contact_no` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES ('15','admin','1','ghulianisikh@gmail.com','$2y$10$RuGKQg6z8yXTfGgpnox.nu1EoH80L3cR3ZPxHZGSLgAiMhv/K9X1m','admin','Jasminder','','wsp_63a027c5dad66451525','','wsp_5d9503aadb182791392','','0','','2019-02-12 22:51:16','Admin','','','','2019-02-12 22:51:16','2020-12-20 15:12:01','','',''),
('16','','0','manavsingh839@gmail.com','$2y$10$l.11T/jf0FpunZas/mL6DuZLzlVuhJDyxIMozPj6ShgqytgZcpKFm','user','','','wsp_63984c5d75c0d35139','','wsp_63984c5d75c24934287','','0','','2022-11-21 16:43:50','Manav Singh','9914649789','','','2022-11-21 11:13:50','2022-11-21 11:13:50','','',''),
('17','jasvir','17','wsp.jasvirsingh@gmail.com','$2y$10$t2NUSK2xs52oQqyry2v2RuhusPhwSF04VsnJwLp.Yc8X0/BsaG1GW','user','','','wsp_63809ac27e10b614779','','','','0','','2022-11-25 16:06:09','Jasvir Singh','9814182914','','active','2022-11-25 10:36:09','2022-11-25 10:36:09','','',''),
('18','','0','jasminderwsp@gmail.com','$2y$10$SQNWchrGKdv9b8UOe4iiMeb/ZJoGILoCy0JmUoWWzQzVzOQ6HS0.6','user','','','wsp_6388d436ee2fe49620','','wsp_6388d436ee30f134011','','0','','2022-11-28 14:05:43','jasminder pal singh','9803345557','','','2022-11-28 8:35:43','2022-11-28 8:35:43','','',''),
('19','','0','manavsingh8391@gmail.com','$2y$10$d66uu4K9ehA6y2XzQyz3wOIJ691uN7v0bH3KRh4c3KYWCI7PIXRsC','user','','','wsp_639c3bea530b0180927','','wsp_639c3bea530bf833547','','0','','2022-11-28 17:43:22','Manav Singh','9023084430','','','2022-11-28 12:13:22','2022-11-28 12:13:22','','',''),
('20','','0','manavsingh8392@gmail.com','$2y$10$BRQKOaTqOFDOmnagSJECVuSgWOpOS8yeg6G3J3/DirkxGvdPnf0eO','user','','','','','','','0','','2022-11-28 17:43:48','Manav Singh','9023084430','','','2022-11-28 12:13:48','2022-11-28 12:13:48','','',''),
('21','','0','manavsingh8393@gmail.com','$2y$10$OZlgLQwXJ6ssDEinnw3tPePrOfR/Pw9cEk48T0kPo0IBJzZY9w35S','user','','','wsp_6384a6cbd40b8445731','','wsp_6384a6cbd40cd846442','','0','','2022-11-28 17:47:14','Manav Singh','9023084430','','','2022-11-28 12:17:14','2022-11-28 12:17:14','','',''),
('22','','0','manavsingh8394@gmail.com','$2y$10$lWrmgKIKdGnMwJCCc457fecrFaspm7A5JZtrAvVLUtSfiE8JLEXXu','user','','','wsp_6384a6f0f0bb3201873','','wsp_6384a6f0f0bc9137753','','0','','2022-11-28 17:47:52','Manav Singh','9023084430','','','2022-11-28 12:17:52','2022-11-28 12:17:52','','',''),
('23','','0','manavsingh8395@gmail.com','$2y$10$usvyXaYx7j3UkS.fUT5Coem3yGiFCm3oBUY1Vj6nEFi.XPoAv33bK','user','','','wsp_6384a7ff75bbf913628','','wsp_6384a7ff75bd1743384','','0','','2022-11-28 17:52:22','Manav Signh','9023084430','','','2022-11-28 12:22:22','2022-11-28 12:22:22','','',''),
('24','','0','jasmind.erwsp@gmail.com','$2y$10$v3K45BpLH80kZsUhahAe2u4LeLUVfltKvR0BwlM4PR3BLiXaUoZ/G','user','','','wsp_63889bdc6adaa406678','','wsp_63889bdc6adbb773618','','0','','2022-11-29 14:57:12','jasminder','980334557','','','2022-11-29 9:27:12','2022-11-29 9:27:12','','',''),
('25','','0','test@gmail.com','$2y$10$1EBPZDbYsZE3cjC9.MzceOgDeiqdZtL.IqJ8oCKI85wUQ8FW4DK4G','user','','','wsp_63872c3d3790f255888','','wsp_63872c3d37920548353','','0','','2022-11-30 14:48:20','Test','9897979797','','','2022-11-30 9:18:20','2022-11-30 9:18:20','','',''),
('26','customer','26','customer@gmail.com','$2y$10$nXOwx3e6u/5xqhnSlAi1JOvkDiboWVAvFUZSIgDGfaMT8bBpErvjK','user','','','','','','','0','','2022-12-01 01:41:13','Customer','','','active','2022-11-30 20:11:13','2022-11-30 20:11:13','','',''),
('27','','0','manavsingh83910@gmail.com','$2y$10$oTG5cUO1A4LozQy57tG7cOyTrD.vBfVBFN0HMkqcXhxWEJ4UaHIY6','user','','','wsp_638f24fb8b980331448','','wsp_638f24fb8b995220451','','0','','2022-12-06 16:46:50','Jashandeep Singh','9041619321','','','2022-12-06 11:16:50','2022-12-06 11:16:50','','',''),
('28','','0','renatas.luzaitis@gmail.com','$2y$10$Vx9zFpr.H8DEPfMNuJip0OyRMkig5kzUH9C26s1g95mt/7vg/pcaO','user','','','wsp_6398be481d85853320','','wsp_6398be481d86f739804','','0','','2022-12-13 23:32:27','Renatas','7447901553','','','2022-12-13 18:02:27','2022-12-13 18:02:27','','',''),
('29','jasminderwspp@gmail.com','0','jasminderwspp@gmail.com','','user','','','','','wsp_639c4413dc273169250','','0','','2022-12-16 15:40:27','kk','','','','2022-12-16 10:10:27','2022-12-16 10:10:27','','',''),
('30','wspkkptesting@gmail.com','0','wspkkptesting@gmail.com','','user','','','','','wsp_639c51574bfa2954855','','0','','2022-12-16 16:37:03','WSP Testing','','','','2022-12-16 11:07:03','2022-12-16 11:07:03','','',''),
('31','harpreetsingh@gmail.com','0','harpreetsingh@gmail.com','','user','','','','','wsp_639c55e00ea36509734','','0','','2022-12-16 16:56:24','harpreet singh','','','','2022-12-16 11:26:24','2022-12-16 11:26:24','','',''),
('32','','0','','','user','','','','','wsp_639c9fc446d14381103','','0','','2022-12-16 22:11:40','','','','','2022-12-16 16:41:40','2022-12-16 16:41:40','','',''),
('33','wsptestingkkp@gmail.com','0','wsptestingkkp@gmail.com','','user','','','','','wsp_639f4c2ce2619211110','','0','','2022-12-18 22:51:48','jasminder','','','','2022-12-18 17:21:48','2022-12-18 17:21:48','','',''),
('34','manavsinghtest@gmail.com','0','manavsinghtest@gmail.com','','user','','','','','wsp_63a027fd3315a275357','','0','','2022-12-19 14:29:41','Manav Singh','','','','2022-12-19 8:59:41','2022-12-19 8:59:41','','',''); 




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

