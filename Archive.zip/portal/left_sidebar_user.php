<ul class="metismenu" id="side-menu">

                            
<li>
<a href="<?php echo $redirection_array[$user_role] ?: $redirection_array["all"]; ?>">
        <i class="fe-list"></i>
        <!-- <span class="badge badge-success float-right">00</span> -->
        <span> Dashboard </span>
    </a>
</li>

<li>
                                <a href="person.php">
                                    <i class="fe-arrow-right-circle"></i>                                  
                                    <span>Person</span>
                                </a>
                            </li>
 



</ul>

