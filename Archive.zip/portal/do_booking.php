<?php
// header("Access-Control-Allow-Origin: *");
// header('Content-Type: application/json');
require("wsp_rad/wsp_rad.inc.php");

$party_size = 2;
$party_date = get_today_date();
$party_time = "18:00";
$party_size_2_interval = 15;
$party_size_4_interval = 15;
$party_size_6_interval = 15;

